import { Monitor, Moon, Sun } from "lucide-react";
import { useMessages } from "@/i18n/provider";
import { cn } from "@/lib/utils";
import { useTheme } from "@/theme/provider";
import type { ThemePreference } from "@/lib/storage";

const OPTIONS: { value: ThemePreference; icon: typeof Sun; labelKey: "light" | "dark" | "system" }[] = [
  { value: "light", icon: Sun, labelKey: "light" },
  { value: "dark", icon: Moon, labelKey: "dark" },
  { value: "system", icon: Monitor, labelKey: "system" },
];

export function ThemeSwitcher({ className }: { className?: string }) {
  const { preference, setPreference } = useTheme();
  const m = useMessages();

  return (
    <div
      role="radiogroup"
      aria-label={m.a11y.theme}
      className={cn(
        "inline-flex h-9 items-center rounded-md bg-stone/70 p-0.5 shadow-border dark:bg-surface",
        className,
      )}
    >
      {OPTIONS.map(({ value, icon: Icon, labelKey }) => {
        const selected = preference === value;
        return (
          <button
            key={value}
            type="button"
            role="radio"
            aria-checked={selected}
            aria-label={m.theme[labelKey]}
            title={m.theme[labelKey]}
            onClick={() => setPreference(value)}
            className={cn(
              "inline-flex size-8 items-center justify-center rounded-sm text-subtle transition-[background-color,color,transform] duration-150 ease-[var(--ease-out)]",
              selected
                ? "bg-surface-elevated text-foreground shadow-border"
                : "hover:text-foreground",
            )}
          >
            <Icon className="size-3.5" strokeWidth={1.75} />
          </button>
        );
      })}
    </div>
  );
}
