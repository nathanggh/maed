import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function SectionHeading({
  eyebrow,
  title,
  body,
  align = "left",
  className,
}: {
  eyebrow?: string;
  title: string;
  body?: ReactNode;
  align?: "left" | "center";
  className?: string;
}) {
  return (
    <div
      className={cn(
        "max-w-2xl",
        align === "center" && "mx-auto text-center",
        className,
      )}
    >
      {eyebrow ? (
        <p className="mb-3 flex items-center gap-3 text-xs font-semibold tracking-[0.18em] text-accent uppercase">
          <span
            aria-hidden="true"
            className={cn(
              "h-px w-7 bg-accent/70",
              align === "center" && "hidden sm:block",
            )}
          />
          <span>{eyebrow}</span>
          {align === "center" ? (
            <span aria-hidden="true" className="hidden h-px w-7 bg-accent/70 sm:block" />
          ) : null}
        </p>
      ) : null}
      <h2 className="font-display text-3xl font-medium leading-[1.15] tracking-[-0.03em] text-foreground sm:text-4xl">
        {title}
      </h2>
      {body ? (
        <p className="mt-4 text-base leading-relaxed text-muted sm:text-[1.05rem]">{body}</p>
      ) : null}
    </div>
  );
}
