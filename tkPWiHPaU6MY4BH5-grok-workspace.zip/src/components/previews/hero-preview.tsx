import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { useMessages } from "@/i18n/provider";
import { cn } from "@/lib/utils";

function useCountUp(target: number) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setValue(target);
      return;
    }
    let start: number | null = null;
    let frame = 0;
    const tick = (t: number) => {
      if (start === null) start = t;
      const p = Math.min(1, (t - start) / 900);
      setValue(Math.round(target * (1 - (1 - p) ** 3)));
      if (p < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [target]);
  return value;
}

function Sparkline({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 120 36" className={cn("h-9 w-[7.5rem]", className)} aria-hidden="true">
      <path
        d="M0 28 C12 26, 18 22, 28 20 S48 24, 58 16 S78 6, 90 10 S110 18, 120 8"
        fill="none"
        className="stroke-accent"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
      <path
        d="M0 28 C12 26, 18 22, 28 20 S48 24, 58 16 S78 6, 90 10 S110 18, 120 8 V36 H0 Z"
        className="fill-accent/15"
      />
    </svg>
  );
}

export function HeroPreview() {
  const m = useMessages();
  const revenue = useCountUp(12480);
  const orders = useCountUp(48);
  const pending = useCountUp(12);
  const verified = useCountUp(36);

  const staff = [
    { name: m.demo.staff_hana, role: m.demo.waiter, state: "ok" as const },
    { name: m.demo.staff_dawit, role: m.demo.cashier, state: "wait" as const },
    { name: m.demo.staff_makeda, role: m.demo.manager, state: "ok" as const },
  ];

  const items = [
    { name: m.demo.item_doro, qty: 14 },
    { name: m.demo.item_tibs, qty: 11 },
    { name: m.demo.item_shiro, qty: 9 },
  ];

  return (
    <div className="preview-stage relative">
      <div
        className={cn(
          "preview-frame overflow-hidden rounded-xl bg-surface-elevated shadow-preview",
          "maed-enter",
        )}
        style={{ animationDelay: "120ms" }}
      >
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="size-2 rounded-full bg-danger/70" />
            <span className="size-2 rounded-full bg-warning/80" />
            <span className="size-2 rounded-full bg-success/70" />
            <span className="ml-2 text-xs font-medium tracking-wide text-subtle">
              {m.brand.name}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Badge tone="bronze">{m.hero.preview_sample}</Badge>
            <span className="hidden text-xs text-subtle sm:inline">{m.hero.preview_today}</span>
          </div>
        </div>

        <div className="grid grid-cols-12">
          <aside className="col-span-3 hidden border-r border-border bg-stone/40 py-4 pr-2 pl-3 sm:block dark:bg-surface">
            <p className="px-2 text-[0.65rem] font-semibold tracking-[0.16em] text-subtle uppercase">
              {m.hero.preview_label}
            </p>
            <ul className="mt-3 space-y-1 text-xs">
              {[m.value.insights, m.value.digital_menu, m.value.orders, m.value.payments, m.value.staff].map(
                (label, i) => (
                  <li
                    key={label}
                    className={cn(
                      "rounded-sm px-2 py-1.5",
                      i === 0 ? "bg-surface-elevated font-medium text-foreground shadow-border" : "text-muted",
                    )}
                  >
                    {label}
                  </li>
                ),
              )}
            </ul>
          </aside>

          <div className="col-span-12 space-y-3 p-3 sm:col-span-9 sm:p-4">
            <article className="rounded-lg bg-surface p-4 shadow-revenue">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xs font-medium tracking-wide text-muted">{m.hero.metric_revenue}</p>
                  <p className="mt-1 font-display text-3xl font-medium tracking-[-0.03em] tabular">
                    {revenue.toLocaleString()}
                    <span className="ml-1.5 text-sm font-sans font-medium text-subtle">
                      {m.hero.currency}
                    </span>
                  </p>
                </div>
                <Sparkline />
              </div>
            </article>

            <div className="grid grid-cols-3 gap-2">
              {[
                { label: m.hero.metric_orders, value: orders, shadow: "shadow-info" },
                { label: m.hero.metric_pending, value: pending, shadow: "shadow-warning" },
                { label: m.hero.metric_verified, value: verified, shadow: "shadow-success" },
              ].map((card) => (
                <article
                  key={card.label}
                  className={cn("rounded-md bg-surface px-3 py-3", card.shadow)}
                >
                  <p className="text-[0.65rem] font-medium tracking-wide text-muted">{card.label}</p>
                  <p className="mt-1 font-display text-xl font-medium tabular">{card.value}</p>
                </article>
              ))}
            </div>

            <div className="grid gap-2 sm:grid-cols-2">
              <article className="rounded-md bg-surface p-3 shadow-card">
                <p className="text-[0.65rem] font-semibold tracking-[0.14em] text-subtle uppercase">
                  {m.hero.staff_activity}
                </p>
                <ul className="mt-2 space-y-2">
                  {staff.map((person) => (
                    <li key={person.name} className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="truncate text-xs font-medium">{person.name}</p>
                        <p className="text-[0.65rem] text-subtle">{person.role}</p>
                      </div>
                      <span
                        className={cn(
                          "size-1.5 shrink-0 rounded-full",
                          person.state === "ok" ? "bg-success" : "bg-warning",
                        )}
                      />
                    </li>
                  ))}
                </ul>
              </article>
              <article className="rounded-md bg-surface p-3 shadow-card">
                <p className="text-[0.65rem] font-semibold tracking-[0.14em] text-subtle uppercase">
                  {m.hero.menu_activity}
                </p>
                <ul className="mt-2 space-y-2">
                  {items.map((item) => (
                    <li key={item.name} className="flex items-center justify-between gap-2 text-xs">
                      <span className="truncate font-medium">{item.name}</span>
                      <span className="tabular text-muted">{item.qty}</span>
                    </li>
                  ))}
                </ul>
              </article>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
