import { ArrowDown } from "lucide-react";
import { Container, Section } from "@/components/layout/container";
import { SectionHeading } from "@/components/ui/section-heading";
import { useMessages } from "@/i18n/provider";

export function Operations() {
  const m = useMessages();
  const steps = [
    m.operations.step_order,
    m.operations.step_record,
    m.operations.step_total,
    m.operations.step_pay,
    m.operations.step_proof,
    m.operations.step_verify,
    m.operations.step_owner,
  ];

  return (
    <Section className="bg-surface">
      <Container>
        <SectionHeading
          eyebrow={m.operations.eyebrow}
          title={m.operations.title}
          body={m.operations.body}
        />
        <ol className="mt-12 max-w-xl">
          {steps.map((step, i) => (
            <li key={step} className="relative flex gap-4 pb-2">
              <div className="flex w-8 shrink-0 flex-col items-center">
                <span className="flex size-8 items-center justify-center rounded-full bg-background font-display text-sm text-accent shadow-border">
                  {i + 1}
                </span>
                {i < steps.length - 1 ? (
                  <ArrowDown className="my-1 size-3.5 text-subtle" strokeWidth={1.5} />
                ) : null}
              </div>
              <p className="pt-1.5 text-sm font-medium sm:text-base">{step}</p>
            </li>
          ))}
        </ol>
        <p className="mt-8 max-w-xl text-sm text-subtle">{m.operations.note}</p>
      </Container>
    </Section>
  );
}
