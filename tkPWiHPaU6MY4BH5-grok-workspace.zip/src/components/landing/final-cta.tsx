import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Container, Section } from "@/components/layout/container";
import { Button } from "@/components/ui/button";
import { useMessages } from "@/i18n/provider";

export function FinalCta() {
  const m = useMessages();
  return (
    <Section className="pb-20 sm:pb-24">
      <Container>
        <div className="rounded-2xl bg-graphite px-6 py-12 text-ivory shadow-lift sm:px-12 sm:py-16">
          <p className="max-w-2xl font-display text-3xl font-medium tracking-[-0.03em] sm:text-4xl">
            {m.cta.title}
          </p>
          <p className="mt-4 max-w-xl text-base leading-relaxed text-ivory/70">{m.cta.body}</p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button
              size="lg"
              className="bg-ivory text-graphite hover:opacity-90"
              asChild
            >
              <Link to="/signup">
                {m.cta.primary}
                <ArrowRight className="size-4" />
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-0 bg-transparent text-ivory ring-1 ring-ivory/20 hover:bg-ivory/10"
              asChild
            >
              <Link to="/contact">{m.cta.secondary}</Link>
            </Button>
          </div>
        </div>
      </Container>
    </Section>
  );
}
