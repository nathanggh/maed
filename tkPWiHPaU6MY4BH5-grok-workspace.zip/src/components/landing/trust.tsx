import { Coffee, Hotel, UtensilsCrossed, Wine, Building2 } from "lucide-react";
import { Container, Section } from "@/components/layout/container";
import { useMessages } from "@/i18n/provider";

export function Trust() {
  const m = useMessages();
  const items = [
    { icon: UtensilsCrossed, title: m.trust.restaurants, body: m.trust.restaurants_body },
    { icon: Hotel, title: m.trust.hotels, body: m.trust.hotels_body },
    { icon: Coffee, title: m.trust.cafes, body: m.trust.cafes_body },
    { icon: Wine, title: m.trust.lounges, body: m.trust.lounges_body },
    { icon: Building2, title: m.trust.hospitality, body: m.trust.hospitality_body },
  ];

  return (
    <Section className="pt-4 sm:pt-6">
      <Container>
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-xs font-semibold tracking-[0.18em] text-accent uppercase">
            {m.trust.eyebrow}
          </p>
          <h2 className="mt-3 font-display text-2xl font-medium tracking-[-0.03em] sm:text-3xl">
            {m.trust.title}
          </h2>
          <p className="mt-3 text-muted">{m.trust.body}</p>
        </div>
        <ul className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {items.map(({ icon: Icon, title, body }) => (
            <li
              key={title}
              className="rounded-lg bg-surface px-4 py-5 shadow-card"
            >
              <Icon className="size-4 text-accent" strokeWidth={1.75} />
              <p className="mt-3 text-sm font-semibold">{title}</p>
              <p className="mt-1.5 text-sm leading-relaxed text-muted">{body}</p>
            </li>
          ))}
        </ul>
      </Container>
    </Section>
  );
}
