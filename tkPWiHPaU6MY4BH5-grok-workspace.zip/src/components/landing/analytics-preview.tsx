import { useEffect, useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Container, Section } from "@/components/layout/container";
import { Badge } from "@/components/ui/badge";
import { SectionHeading } from "@/components/ui/section-heading";
import { useMessages } from "@/i18n/provider";
import { cn } from "@/lib/utils";

const TREND = [
  { d: "1", v: 8400 },
  { d: "2", v: 9200 },
  { d: "3", v: 7800 },
  { d: "4", v: 11000 },
  { d: "5", v: 12480 },
  { d: "6", v: 10100 },
  { d: "7", v: 13200 },
];

export function AnalyticsPreview() {
  const m = useMessages();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const axis = "var(--maed-subtle)";
  const gold = "var(--maed-accent)";
  const mix = [
    { name: m.analytics.cash, value: 42, bar: "bg-accent" },
    { name: m.analytics.telebirr, value: 38, bar: "bg-info" },
    { name: m.analytics.bank, value: 20, bar: "bg-success" },
  ];
  const popular = [
    { name: m.demo.item_doro, v: 42 },
    { name: m.demo.item_tibs, v: 31 },
    { name: m.demo.item_shiro, v: 24 },
    { name: m.demo.item_coffee, v: 19 },
  ];

  return (
    <Section>
      <Container>
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <SectionHeading
            eyebrow={m.analytics.eyebrow}
            title={m.analytics.title}
            body={m.analytics.body}
          />
          <Badge tone="bronze">{m.analytics.sample}</Badge>
        </div>

        <div className="mt-12 grid gap-4 lg:grid-cols-12">
          <article className="rounded-xl bg-surface p-5 shadow-revenue lg:col-span-7">
            <p className="text-xs font-semibold tracking-[0.14em] text-subtle uppercase">
              {m.analytics.trends}
            </p>
            <p className="mt-2 font-display text-3xl font-medium tabular">
              12,480
              <span className="ml-1.5 font-sans text-sm font-medium text-subtle">{m.hero.currency}</span>
            </p>
            <div className="mt-4 h-44">
              {mounted ? (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={TREND} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={gold} stopOpacity={0.28} />
                        <stop offset="100%" stopColor={gold} stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="d" tick={{ fill: axis, fontSize: 11 }} axisLine={false} tickLine={false} />
                    <YAxis hide />
                    <Tooltip
                      contentStyle={{
                        background: "var(--maed-surface-elevated)",
                        border: "1px solid var(--maed-border)",
                        borderRadius: 8,
                        fontSize: 12,
                      }}
                    />
                    <Area type="monotone" dataKey="v" stroke={gold} strokeWidth={1.8} fill="url(#rev)" />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full rounded-md bg-stone/50" />
              )}
            </div>
          </article>

          <article className="rounded-xl bg-surface p-5 shadow-info lg:col-span-5">
            <p className="text-xs font-semibold tracking-[0.14em] text-subtle uppercase">
              {m.analytics.methods}
            </p>
            <ul className="mt-5 space-y-4">
              {mix.map((row) => (
                <li key={row.name}>
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">{row.name}</span>
                    <span className="tabular text-muted">{row.value}%</span>
                  </div>
                  <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-stone">
                    <div
                      className={cn("h-full rounded-full", row.bar)}
                      style={{ width: `${row.value}%` }}
                    />
                  </div>
                </li>
              ))}
            </ul>
          </article>

          <article className="rounded-xl bg-surface p-5 shadow-card lg:col-span-7">
            <p className="text-xs font-semibold tracking-[0.14em] text-subtle uppercase">
              {m.analytics.popular}
            </p>
            <div className="mt-4 h-44">
              {mounted ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={popular} layout="vertical" margin={{ top: 0, right: 8, left: 8, bottom: 0 }}>
                    <XAxis type="number" hide />
                    <YAxis
                      type="category"
                      dataKey="name"
                      width={96}
                      tick={{ fill: axis, fontSize: 11 }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Bar dataKey="v" radius={[0, 4, 4, 0]} barSize={12}>
                      {popular.map((entry) => (
                        <Cell key={entry.name} fill={gold} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full rounded-md bg-stone/50" />
              )}
            </div>
          </article>

          <article className="rounded-xl bg-surface p-5 shadow-success lg:col-span-5">
            <p className="text-xs font-semibold tracking-[0.14em] text-subtle uppercase">
              {m.analytics.staff}
            </p>
            <ul className="mt-4 space-y-3">
              {[
                { name: m.demo.staff_hana, role: m.demo.waiter, n: 18 },
                { name: m.demo.staff_dawit, role: m.demo.cashier, n: 36 },
                { name: m.demo.staff_makeda, role: m.demo.manager, n: 9 },
              ].map((row) => (
                <li key={row.name} className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-medium">{row.name}</p>
                    <p className="text-xs text-subtle">{row.role}</p>
                  </div>
                  <p className="tabular text-sm text-muted">
                    {row.n} {m.analytics.tickets}
                  </p>
                </li>
              ))}
            </ul>
          </article>
        </div>
      </Container>
    </Section>
  );
}
