import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Container } from "@/components/layout/container";
import { HeroPreview } from "@/components/previews/hero-preview";
import { Button } from "@/components/ui/button";
import { useMessages } from "@/i18n/provider";

export function Hero() {
  const m = useMessages();
  return (
    <section className="relative overflow-hidden pt-10 pb-16 sm:pt-14 sm:pb-20 lg:pt-16 lg:pb-24">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(70%_50%_at_78%_0%,color-mix(in_oklab,var(--maed-gold)_10%,transparent),transparent_68%)]"
      />
      <Container className="relative grid items-center gap-12 lg:grid-cols-12 lg:gap-10">
        <div className="lg:col-span-5">
          <p
            className="maed-enter mb-4 text-xs font-semibold tracking-[0.18em] text-accent uppercase"
            style={{ animationDelay: "40ms" }}
          >
            {m.hero.eyebrow}
          </p>
          <h1
            className="maed-enter font-display text-[2.35rem] leading-[1.08] font-medium tracking-[-0.035em] text-foreground sm:text-5xl lg:text-[3.35rem]"
            style={{ animationDelay: "80ms" }}
          >
            {m.hero.title}
          </h1>
          <p
            className="maed-enter mt-5 max-w-md text-base leading-relaxed text-muted sm:text-lg"
            style={{ animationDelay: "140ms" }}
          >
            {m.hero.subtitle}
          </p>
          <div
            className="maed-enter mt-8 flex flex-col gap-3 sm:flex-row sm:items-center"
            style={{ animationDelay: "200ms" }}
          >
            <Button size="lg" asChild>
              <Link to="/signup">
                {m.hero.cta_primary}
                <ArrowRight className="size-4" />
              </Link>
            </Button>
            <Button size="lg" variant="secondary" asChild>
              <Link to="/" hash="product">
                {m.hero.cta_secondary}
              </Link>
            </Button>
          </div>
        </div>
        <div className="lg:col-span-7 lg:pl-4">
          <div className="maed-float">
            <HeroPreview />
          </div>
        </div>
      </Container>
    </section>
  );
}
