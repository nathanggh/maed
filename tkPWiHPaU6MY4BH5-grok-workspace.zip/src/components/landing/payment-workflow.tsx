import { ArrowRight } from "lucide-react";
import { Container, Section } from "@/components/layout/container";
import { Badge } from "@/components/ui/badge";
import { SectionHeading } from "@/components/ui/section-heading";
import { useMessages } from "@/i18n/provider";
import { cn } from "@/lib/utils";

export function PaymentWorkflow() {
  const m = useMessages();
  const steps = [
    { label: m.payments.order, tone: "neutral" as const },
    { label: m.payments.unpaid, tone: "warning" as const },
    { label: m.payments.submitted, tone: "info" as const },
    { label: m.payments.pending, tone: "warning" as const },
    { label: m.payments.verified, tone: "success" as const },
  ];
  const methods = [m.payments.cash, m.payments.telebirr, m.payments.bank, m.payments.other];

  return (
    <Section className="bg-surface">
      <Container>
        <SectionHeading
          eyebrow={m.payments.eyebrow}
          title={m.payments.title}
          body={m.payments.body}
        />
        <div className="mt-12 overflow-x-auto pb-2">
          <ol className="flex min-w-max items-center gap-2">
            {steps.map((step, i) => (
              <li key={step.label} className="flex items-center gap-2">
                <span
                  className={cn(
                    "rounded-md px-3 py-2 text-sm font-medium shadow-border",
                    step.tone === "success" && "bg-success/12 text-success shadow-success",
                    step.tone === "warning" && "bg-warning/12 text-warning shadow-warning",
                    step.tone === "info" && "bg-info/12 text-info shadow-info",
                    step.tone === "neutral" && "bg-background text-foreground",
                  )}
                >
                  {step.label}
                </span>
                {i < steps.length - 1 ? (
                  <ArrowRight className="size-4 text-subtle" strokeWidth={1.5} />
                ) : null}
              </li>
            ))}
          </ol>
        </div>
        <div className="mt-8 grid gap-4 lg:grid-cols-2">
          <article className="rounded-xl bg-background p-5 shadow-card">
            <p className="text-xs font-semibold tracking-[0.14em] text-subtle uppercase">
              {m.payments.methods_label}
            </p>
            <ul className="mt-4 flex flex-wrap gap-2">
              {methods.map((method) => (
                <li key={method}>
                  <Badge tone="neutral">{method}</Badge>
                </li>
              ))}
            </ul>
          </article>
          <article className="rounded-xl bg-background p-5 shadow-success">
            <p className="text-xs font-semibold tracking-[0.14em] text-subtle uppercase">
              {m.payments.proof_title}
            </p>
            <p className="mt-3 text-sm leading-relaxed text-muted">{m.payments.proof_body}</p>
          </article>
        </div>
        <p className="mt-6 text-sm text-subtle">{m.payments.note}</p>
      </Container>
    </Section>
  );
}
