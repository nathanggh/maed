import { Container, Section } from "@/components/layout/container";
import { SectionHeading } from "@/components/ui/section-heading";
import { useMessages } from "@/i18n/provider";

export function HowItWorks() {
  const m = useMessages();
  const steps = [
    { n: "01", title: m.how.step1_title, body: m.how.step1_body },
    { n: "02", title: m.how.step2_title, body: m.how.step2_body },
    { n: "03", title: m.how.step3_title, body: m.how.step3_body },
    { n: "04", title: m.how.step4_title, body: m.how.step4_body },
  ];

  return (
    <Section className="bg-surface">
      <Container>
        <SectionHeading eyebrow={m.how.eyebrow} title={m.how.title} body={m.how.body} />
        <ol className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, i) => (
            <li key={step.n} className="relative">
              {i < steps.length - 1 ? (
                <span
                  aria-hidden="true"
                  className="absolute top-5 left-[2.25rem] hidden h-px w-[calc(100%-1rem)] bg-border lg:block"
                />
              ) : null}
              <p className="font-display text-2xl font-medium text-accent/80">{step.n}</p>
              <h3 className="mt-3 text-base font-semibold">{step.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">{step.body}</p>
            </li>
          ))}
        </ol>
      </Container>
    </Section>
  );
}
