import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Container, Section } from "@/components/layout/container";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/ui/section-heading";
import { useMessages } from "@/i18n/provider";
import { cn } from "@/lib/utils";

export function PricingTeaser() {
  const m = useMessages();
  const plans = [
    { name: m.pricing.trial, meta: m.pricing.trial_meta, featured: true },
    { name: m.pricing.pro, meta: "—", featured: false },
    { name: m.pricing.pro_plus, meta: "—", featured: false },
    { name: m.pricing.premium, meta: "—", featured: false },
    { name: m.pricing.enterprise, meta: "—", featured: false },
  ];

  return (
    <Section id="pricing">
      <Container>
        <SectionHeading eyebrow={m.pricing.eyebrow} title={m.pricing.title} body={m.pricing.body} />
        <ul className="mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {plans.map((plan) => (
            <li
              key={plan.name}
              className={cn(
                "rounded-xl p-5",
                plan.featured ? "bg-primary text-primary-foreground shadow-lift" : "bg-surface shadow-card",
              )}
            >
              <p className="text-sm font-semibold">{plan.name}</p>
              <p
                className={cn(
                  "mt-2 font-display text-2xl font-medium",
                  plan.featured ? "text-primary-foreground" : "text-foreground",
                )}
              >
                {plan.meta}
              </p>
              {plan.featured ? (
                <p className="mt-3 text-sm text-primary-foreground/80">{m.pricing.trial_body}</p>
              ) : null}
            </li>
          ))}
        </ul>
        <p className="mt-6 text-sm text-subtle">{m.pricing.coming}</p>
        <div className="mt-8">
          <Button asChild>
            <Link to="/pricing">
              {m.pricing.explore}
              <ArrowRight className="size-4" />
            </Link>
          </Button>
        </div>
      </Container>
    </Section>
  );
}
