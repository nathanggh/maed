import { AnalyticsPreview } from "@/components/landing/analytics-preview";
import { CoreValue } from "@/components/landing/core-value";
import { FinalCta } from "@/components/landing/final-cta";
import { Hero } from "@/components/landing/hero";
import { HowItWorks } from "@/components/landing/how-it-works";
import { MultiBusiness } from "@/components/landing/multi-business";
import { Offline } from "@/components/landing/offline";
import { Operations } from "@/components/landing/operations";
import { PaymentWorkflow } from "@/components/landing/payment-workflow";
import { PricingTeaser } from "@/components/landing/pricing-teaser";
import { StaffWorkflow } from "@/components/landing/staff-workflow";
import { Trust } from "@/components/landing/trust";
import { UseCases } from "@/components/landing/use-cases";

export function LandingPage() {
  return (
    <>
      <Hero />
      <Trust />
      <CoreValue />
      <HowItWorks />
      <UseCases />
      <Operations />
      <Offline />
      <MultiBusiness />
      <StaffWorkflow />
      <PaymentWorkflow />
      <AnalyticsPreview />
      <PricingTeaser />
      <FinalCta />
    </>
  );
}
