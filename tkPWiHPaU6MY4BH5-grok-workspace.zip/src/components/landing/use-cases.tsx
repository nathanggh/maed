import { useState } from "react";
import { Check } from "lucide-react";
import { Container, Section } from "@/components/layout/container";
import { Badge } from "@/components/ui/badge";
import { SectionHeading } from "@/components/ui/section-heading";
import { useMessages } from "@/i18n/provider";
import { cn } from "@/lib/utils";

type CaseKey = "restaurants" | "cafes" | "hotels" | "lounges" | "other";

export function UseCases() {
  const m = useMessages();
  const [active, setActive] = useState<CaseKey>("restaurants");

  const cases: Record<
    CaseKey,
    { label: string; lead: string; body: string; caps: string[]; preview: string[] }
  > = {
    restaurants: {
      label: m.use_cases.restaurants,
      lead: m.use_cases.restaurants_lead,
      body: m.use_cases.restaurants_body,
      caps: [m.use_cases.restaurants_c1, m.use_cases.restaurants_c2, m.use_cases.restaurants_c3],
      preview: [m.demo.item_doro, m.demo.item_tibs, m.demo.item_shiro],
    },
    cafes: {
      label: m.use_cases.cafes,
      lead: m.use_cases.cafes_lead,
      body: m.use_cases.cafes_body,
      caps: [m.use_cases.cafes_c1, m.use_cases.cafes_c2, m.use_cases.cafes_c3],
      preview: [m.demo.item_coffee, m.demo.item_chechebsa, m.demo.item_shiro],
    },
    hotels: {
      label: m.use_cases.hotels,
      lead: m.use_cases.hotels_lead,
      body: m.use_cases.hotels_body,
      caps: [m.use_cases.hotels_c1, m.use_cases.hotels_c2, m.use_cases.hotels_c3],
      preview: [m.multi.hotel_bole, m.multi.hotel_airport, m.multi.cafe],
    },
    lounges: {
      label: m.use_cases.lounges,
      lead: m.use_cases.lounges_lead,
      body: m.use_cases.lounges_body,
      caps: [m.use_cases.lounges_c1, m.use_cases.lounges_c2, m.use_cases.lounges_c3],
      preview: [m.demo.staff_hana, m.demo.staff_dawit, m.demo.staff_yonas],
    },
    other: {
      label: m.use_cases.other,
      lead: m.use_cases.other_lead,
      body: m.use_cases.other_body,
      caps: [m.use_cases.other_c1, m.use_cases.other_c2, m.use_cases.other_c3],
      preview: [m.demo.item_chechebsa, m.demo.item_coffee, m.demo.item_tibs],
    },
  };

  const current = cases[active];
  const keys = Object.keys(cases) as CaseKey[];

  return (
    <Section id="solutions">
      <Container>
        <SectionHeading
          eyebrow={m.use_cases.eyebrow}
          title={m.use_cases.title}
          body={m.use_cases.body}
        />
        <div className="mt-10 grid gap-8 lg:grid-cols-12">
          <div className="flex gap-2 overflow-x-auto pb-1 lg:col-span-4 lg:flex-col lg:overflow-visible">
            {keys.map((key) => (
              <button
                key={key}
                type="button"
                onClick={() => setActive(key)}
                className={cn(
                  "min-h-11 shrink-0 rounded-md px-4 py-3 text-left text-sm font-medium transition-colors duration-150",
                  active === key
                    ? "bg-primary text-primary-foreground shadow-border"
                    : "bg-surface text-muted shadow-border hover:text-foreground",
                )}
              >
                {cases[key].label}
              </button>
            ))}
          </div>
          <div className="lg:col-span-8">
            <article className="rounded-xl bg-surface p-6 shadow-card sm:p-8">
              <h3 className="font-display text-2xl font-medium tracking-[-0.03em]">
                {current.lead}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-muted sm:text-base">{current.body}</p>
              <ul className="mt-6 space-y-2">
                {current.caps.map((cap) => (
                  <li key={cap} className="flex items-start gap-2 text-sm">
                    <Check className="mt-0.5 size-4 shrink-0 text-accent" strokeWidth={1.75} />
                    <span>{cap}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-6 rounded-lg bg-background p-4 shadow-border">
                <div className="mb-3 flex items-center justify-between">
                  <p className="text-xs font-semibold tracking-[0.14em] text-subtle uppercase">
                    {m.hero.preview_label}
                  </p>
                  <Badge tone="bronze">{m.hero.preview_sample}</Badge>
                </div>
                <ul className="space-y-2">
                  {current.preview.map((row, i) => (
                    <li
                      key={row}
                      className="flex items-center justify-between rounded-sm bg-surface px-3 py-2 text-sm"
                    >
                      <span className="font-medium">{row}</span>
                      <span className="tabular text-subtle">{i === 0 ? "01" : i === 1 ? "02" : "03"}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </article>
          </div>
        </div>
      </Container>
    </Section>
  );
}
