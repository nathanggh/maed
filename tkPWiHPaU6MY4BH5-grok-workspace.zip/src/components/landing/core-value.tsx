import {
  BookOpen,
  GitBranch,
  LineChart,
  ClipboardList,
  Users,
  Wallet,
} from "lucide-react";
import { Container, Section } from "@/components/layout/container";
import { SectionHeading } from "@/components/ui/section-heading";
import { useMessages } from "@/i18n/provider";
import { cn } from "@/lib/utils";

export function CoreValue() {
  const m = useMessages();
  const pillars = [
    { icon: BookOpen, title: m.value.digital_menu, body: m.value.digital_menu_body, shadow: "shadow-card" },
    { icon: Users, title: m.value.staff, body: m.value.staff_body, shadow: "shadow-info" },
    { icon: ClipboardList, title: m.value.orders, body: m.value.orders_body, shadow: "shadow-warning" },
    { icon: Wallet, title: m.value.payments, body: m.value.payments_body, shadow: "shadow-success" },
    { icon: GitBranch, title: m.value.branches, body: m.value.branches_body, shadow: "shadow-info" },
    { icon: LineChart, title: m.value.insights, body: m.value.insights_body, shadow: "shadow-revenue" },
  ];

  return (
    <Section id="product">
      <Container>
        <SectionHeading eyebrow={m.value.eyebrow} title={m.value.title} body={m.value.body} />
        <ul className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {pillars.map(({ icon: Icon, title, body, shadow }) => (
            <li key={title} className={cn("rounded-xl bg-surface p-6", shadow)}>
              <div className="flex size-10 items-center justify-center rounded-md bg-stone text-accent">
                <Icon className="size-4" strokeWidth={1.75} />
              </div>
              <h3 className="mt-5 text-base font-semibold">{title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">{body}</p>
            </li>
          ))}
        </ul>
      </Container>
    </Section>
  );
}
