import { ArrowDown, Wifi, WifiOff } from "lucide-react";
import { Container, Section } from "@/components/layout/container";
import { SectionHeading } from "@/components/ui/section-heading";
import { useMessages } from "@/i18n/provider";

function Flow({
  title,
  icon,
  steps,
}: {
  title: string;
  icon: typeof Wifi;
  steps: string[];
}) {
  const Icon = icon;
  return (
    <article className="rounded-xl bg-surface p-6 shadow-card">
      <div className="flex items-center gap-2">
        <span className="flex size-9 items-center justify-center rounded-md bg-stone text-accent">
          <Icon className="size-4" strokeWidth={1.75} />
        </span>
        <h3 className="text-sm font-semibold tracking-[0.12em] uppercase">{title}</h3>
      </div>
      <ol className="mt-5">
        {steps.map((step, i) => (
          <li key={step} className="flex flex-col items-start">
            <p className="rounded-md bg-background px-3 py-2 text-sm font-medium shadow-border">
              {step}
            </p>
            {i < steps.length - 1 ? (
              <ArrowDown className="my-1.5 ml-3 size-3.5 text-subtle" strokeWidth={1.5} />
            ) : null}
          </li>
        ))}
      </ol>
    </article>
  );
}

export function Offline() {
  const m = useMessages();
  return (
    <Section>
      <Container>
        <SectionHeading eyebrow={m.offline.eyebrow} title={m.offline.title} body={m.offline.body} />
        <div className="mt-12 grid gap-4 lg:grid-cols-2">
          <Flow
            title={m.offline.online}
            icon={Wifi}
            steps={[m.offline.online, m.offline.order, m.offline.payment, m.offline.sync]}
          />
          <Flow
            title={m.offline.offline}
            icon={WifiOff}
            steps={[
              m.offline.offline,
              m.offline.order_saved,
              m.offline.payment_recorded,
              m.offline.connection_returns,
              m.offline.secure_sync,
            ]}
          />
        </div>
        <p className="mt-6 text-sm text-subtle">{m.offline.note}</p>
      </Container>
    </Section>
  );
}
