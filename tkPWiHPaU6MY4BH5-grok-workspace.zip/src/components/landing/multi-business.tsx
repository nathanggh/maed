import { Container, Section } from "@/components/layout/container";
import { Badge } from "@/components/ui/badge";
import { SectionHeading } from "@/components/ui/section-heading";
import { useMessages } from "@/i18n/provider";

export function MultiBusiness() {
  const m = useMessages();
  return (
    <Section className="bg-surface">
      <Container>
        <div className="grid items-start gap-12 lg:grid-cols-12">
          <div className="lg:col-span-6">
            <SectionHeading eyebrow={m.multi.eyebrow} title={m.multi.title} body={m.multi.body} />
            <p className="mt-6 text-sm text-subtle">{m.multi.note}</p>
          </div>
          <div className="lg:col-span-6">
            <div className="rounded-xl bg-background p-5 shadow-card sm:p-6">
              <p className="text-xs font-semibold tracking-[0.16em] text-subtle uppercase">
                {m.multi.owner}
              </p>
              <div className="mt-4 space-y-3 border-l border-border pl-4">
                <div>
                  <p className="text-sm font-semibold">{m.multi.hotel}</p>
                  <ul className="mt-2 space-y-1 border-l border-border pl-4 text-sm text-muted">
                    <li>{m.multi.hotel_bole}</li>
                    <li>{m.multi.hotel_airport}</li>
                  </ul>
                </div>
                <p className="text-sm font-semibold">{m.multi.cafe}</p>
                <p className="text-sm font-semibold">{m.multi.restaurant}</p>
              </div>
              <div className="mt-6 rounded-lg bg-surface p-4 shadow-border">
                <div className="flex items-center justify-between gap-3">
                  <p className="text-xs font-medium text-muted">{m.multi.workspace}</p>
                  <Badge tone="bronze">{m.hero.preview_sample}</Badge>
                </div>
                <p className="mt-2 font-mono text-sm text-foreground">{m.multi.workspace_example}</p>
                <p className="mt-2 text-sm text-muted">{m.multi.workspace_note}</p>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </Section>
  );
}
