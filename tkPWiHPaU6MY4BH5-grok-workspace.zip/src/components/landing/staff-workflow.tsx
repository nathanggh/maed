import { ArrowDown } from "lucide-react";
import { Container, Section } from "@/components/layout/container";
import { SectionHeading } from "@/components/ui/section-heading";
import { useMessages } from "@/i18n/provider";

export function StaffWorkflow() {
  const m = useMessages();
  const roles = [
    { title: m.staff.owner, body: m.staff.owner_body },
    { title: m.staff.admin, body: m.staff.admin_body },
    { title: m.staff.cashier, body: m.staff.cashier_body },
    { title: m.staff.waiter, body: m.staff.waiter_body },
  ];

  return (
    <Section>
      <Container>
        <SectionHeading eyebrow={m.staff.eyebrow} title={m.staff.title} body={m.staff.body} />
        <div className="mt-12 flex flex-col gap-3 lg:flex-row lg:items-stretch">
          {roles.map((role, i) => (
            <div key={role.title} className="flex flex-1 flex-col items-stretch lg:flex-row">
              <article className="flex-1 rounded-xl bg-surface p-5 shadow-card">
                <p className="text-xs font-semibold tracking-[0.16em] text-accent uppercase">
                  {String(i + 1).padStart(2, "0")}
                </p>
                <h3 className="mt-2 text-base font-semibold">{role.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted">{role.body}</p>
              </article>
              {i < roles.length - 1 ? (
                <div className="flex items-center justify-center px-1 py-1 lg:px-2">
                  <ArrowDown className="size-4 text-subtle lg:-rotate-90" strokeWidth={1.5} />
                </div>
              ) : null}
            </div>
          ))}
        </div>
        <p className="mt-6 text-sm text-subtle">{m.staff.note}</p>
      </Container>
    </Section>
  );
}
