import { Link } from "@tanstack/react-router";
import { useMessages } from "@/i18n/provider";
import { cn } from "@/lib/utils";

export function BrandMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("size-7 shrink-0", className)}
      aria-hidden="true"
    >
      <rect width="32" height="32" rx="8" className="fill-primary" />
      <path
        d="M16 5.2 26.2 11v10L16 26.8 5.8 21V11Z"
        fill="none"
        className="stroke-gold"
        strokeWidth="1.4"
        strokeLinejoin="round"
      />
      <path
        d="M16 11.2 21.4 14.3v6.2L16 23.6l-5.4-3.1v-6.2Z"
        fill="none"
        className="stroke-gold"
        strokeWidth="1.2"
        strokeLinejoin="round"
      />
      <circle cx="16" cy="17.4" r="1.35" className="fill-gold" />
    </svg>
  );
}

export function Wordmark({
  className,
  compact = false,
}: {
  className?: string;
  compact?: boolean;
}) {
  const m = useMessages();
  return (
    <Link
      to="/"
      className={cn(
        "group inline-flex items-center gap-2.5 rounded-sm text-foreground focus-visible:outline-none",
        className,
      )}
      aria-label={m.brand.name}
    >
      <BrandMark />
      <span className="flex items-baseline gap-1.5 leading-none">
        <span className="font-display text-[1.15rem] font-semibold tracking-[-0.03em]">
          {m.brand.maed}
        </span>
        {!compact ? (
          <span className="font-sans text-[0.68rem] font-semibold tracking-[0.22em] text-muted">
            {m.brand.menu}
          </span>
        ) : null}
      </span>
    </Link>
  );
}
