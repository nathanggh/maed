import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Wordmark } from "@/components/brand/wordmark";
import { LanguageSwitcher } from "@/components/i18n/language-switcher";
import { ThemeSwitcher } from "@/components/theme/theme-switcher";
import { Button } from "@/components/ui/button";
import { Container } from "@/components/layout/container";
import { useMessages } from "@/i18n/provider";
import { cn } from "@/lib/utils";

function useScrolled(threshold = 12) {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > threshold);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [threshold]);
  return scrolled;
}

export function Navbar() {
  const m = useMessages();
  const scrolled = useScrolled();
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open]);

  const links = [
    { hash: "product", label: m.nav.product },
    { hash: "solutions", label: m.nav.solutions },
    { to: "/pricing" as const, label: m.nav.pricing },
    { to: "/help" as const, label: m.nav.resources },
  ];

  return (
    <header
      className={cn(
        "sticky top-0 z-40 transition-[background-color,box-shadow,backdrop-filter] duration-200 ease-[var(--ease-out)]",
        scrolled || open
          ? "border-b border-border bg-background/80 shadow-border backdrop-blur-md"
          : "bg-transparent",
      )}
    >
      <Container className="flex h-16 items-center justify-between gap-4 lg:h-[4.25rem]">
        <Wordmark />

        <nav
          aria-label={m.a11y.primary_nav}
          className="hidden items-center gap-1 lg:flex"
        >
          {links.map((link) =>
            "to" in link && link.to ? (
              <Link
                key={link.label}
                to={link.to}
                className="rounded-sm px-3 py-2 text-sm font-medium text-muted transition-colors duration-150 hover:text-foreground"
              >
                {link.label}
              </Link>
            ) : (
              <Link
                key={link.label}
                to="/"
                hash={"hash" in link ? link.hash : undefined}
                className="rounded-sm px-3 py-2 text-sm font-medium text-muted transition-colors duration-150 hover:text-foreground"
              >
                {link.label}
              </Link>
            ),
          )}
        </nav>

        <div className="hidden items-center gap-2 lg:flex">
          <LanguageSwitcher />
          <ThemeSwitcher />
          <Button variant="ghost" size="sm" asChild>
            <Link to="/login">{m.nav.sign_in}</Link>
          </Button>
          <Button size="sm" asChild>
            <Link to="/signup">{m.nav.get_started}</Link>
          </Button>
        </div>

        <button
          type="button"
          className="inline-flex size-11 items-center justify-center rounded-md text-foreground lg:hidden"
          aria-label={open ? m.a11y.close_menu : m.a11y.open_menu}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </Container>

      <div
        className={cn(
          "lg:hidden",
          open ? "block" : "hidden",
        )}
      >
        <div className="border-t border-border bg-background">
          <Container className="flex flex-col gap-1 py-4">
            {links.map((link) =>
              "to" in link && link.to ? (
                <Link
                  key={link.label}
                  to={link.to}
                  className="rounded-md px-3 py-3 text-base font-medium text-foreground"
                >
                  {link.label}
                </Link>
              ) : (
                <Link
                  key={link.label}
                  to="/"
                  hash={"hash" in link ? link.hash : undefined}
                  className="rounded-md px-3 py-3 text-base font-medium text-foreground"
                  onClick={() => setOpen(false)}
                >
                  {link.label}
                </Link>
              ),
            )}
            <div className="mt-3 flex items-center justify-between gap-3 px-1">
              <LanguageSwitcher />
              <ThemeSwitcher />
            </div>
            <div className="mt-4 flex flex-col gap-2">
              <Button variant="secondary" asChild>
                <Link to="/login">{m.nav.sign_in}</Link>
              </Button>
              <Button asChild>
                <Link to="/signup">{m.nav.get_started}</Link>
              </Button>
            </div>
          </Container>
        </div>
      </div>
    </header>
  );
}
