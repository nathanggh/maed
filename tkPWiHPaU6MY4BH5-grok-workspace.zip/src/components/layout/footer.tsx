import { Link } from "@tanstack/react-router";
import { Wordmark } from "@/components/brand/wordmark";
import { LanguageSwitcher } from "@/components/i18n/language-switcher";
import { Container } from "@/components/layout/container";
import { useMessages } from "@/i18n/provider";

type FooterTo =
  | "/"
  | "/pricing"
  | "/about"
  | "/contact"
  | "/careers"
  | "/help"
  | "/docs"
  | "/support"
  | "/privacy"
  | "/terms"
  | "/updates";

type FooterLink = { label: string; to: FooterTo; hash?: string };

export function Footer() {
  const m = useMessages();

  const columns: { title: string; links: FooterLink[] }[] = [
    {
      title: m.footer.product,
      links: [
        { label: m.footer.features, to: "/", hash: "product" },
        { label: m.footer.pricing, to: "/pricing" },
        { label: m.footer.updates, to: "/updates" },
      ],
    },
    {
      title: m.footer.solutions,
      links: [
        { label: m.footer.restaurants, to: "/", hash: "solutions" },
        { label: m.footer.hotels, to: "/", hash: "solutions" },
        { label: m.footer.cafes, to: "/", hash: "solutions" },
        { label: m.footer.hospitality, to: "/", hash: "solutions" },
      ],
    },
    {
      title: m.footer.company,
      links: [
        { label: m.footer.about, to: "/about" },
        { label: m.footer.contact, to: "/contact" },
        { label: m.footer.careers, to: "/careers" },
      ],
    },
    {
      title: m.footer.resources,
      links: [
        { label: m.footer.help, to: "/help" },
        { label: m.footer.docs, to: "/docs" },
        { label: m.footer.support, to: "/support" },
      ],
    },
    {
      title: m.footer.legal,
      links: [
        { label: m.footer.privacy, to: "/privacy" },
        { label: m.footer.terms, to: "/terms" },
      ],
    },
  ];

  return (
    <footer className="border-t border-border bg-surface">
      <Container className="py-14 lg:py-16">
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <Wordmark />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted">{m.footer.tagline}</p>
          </div>
          <nav
            aria-label={m.a11y.footer_nav}
            className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:col-span-8 lg:grid-cols-5"
          >
            {columns.map((col) => (
              <div key={col.title}>
                <p className="text-xs font-semibold tracking-[0.16em] text-subtle uppercase">
                  {col.title}
                </p>
                <ul className="mt-3 space-y-2">
                  {col.links.map((link) => (
                    <li key={link.label}>
                      <Link
                        to={link.to}
                        hash={link.hash}
                        className="text-sm text-muted transition-colors duration-150 hover:text-foreground"
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </nav>
        </div>
        <div className="mt-12 flex flex-col gap-4 border-t border-border pt-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-sm text-subtle">{m.footer.copyright}</p>
          <LanguageSwitcher />
        </div>
      </Container>
    </footer>
  );
}
