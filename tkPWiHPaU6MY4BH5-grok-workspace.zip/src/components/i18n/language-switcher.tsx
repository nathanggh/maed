import { useI18n } from "@/i18n/provider";
import { cn } from "@/lib/utils";
import type { Locale } from "@/lib/storage";

const OPTIONS: { value: Locale; short: string }[] = [
  { value: "en", short: "EN" },
  { value: "am", short: "አማ" },
];

export function LanguageSwitcher({ className }: { className?: string }) {
  const { locale, setLocale, messages } = useI18n();

  return (
    <div
      role="radiogroup"
      aria-label={messages.a11y.language}
      className={cn(
        "inline-flex h-9 items-center rounded-md bg-stone/70 p-0.5 shadow-border dark:bg-surface",
        className,
      )}
    >
      {OPTIONS.map(({ value, short }) => {
        const selected = locale === value;
        return (
          <button
            key={value}
            type="button"
            role="radio"
            aria-checked={selected}
            aria-label={messages.language[value]}
            title={messages.language[value]}
            onClick={() => setLocale(value)}
            className={cn(
              "inline-flex h-8 min-w-9 items-center justify-center rounded-sm px-2 text-[0.7rem] font-semibold tracking-wide text-subtle transition-[background-color,color] duration-150 ease-[var(--ease-out)]",
              selected
                ? "bg-surface-elevated text-foreground shadow-border"
                : "hover:text-foreground",
            )}
          >
            {short}
          </button>
        );
      })}
    </div>
  );
}
