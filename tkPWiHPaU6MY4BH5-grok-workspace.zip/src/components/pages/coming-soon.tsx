import { Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { Container } from "@/components/layout/container";
import { Button } from "@/components/ui/button";
import { useMessages } from "@/i18n/provider";

export function ComingSoon({
  title,
  body,
  extra,
}: {
  title: string;
  body: string;
  extra?: string;
}) {
  const m = useMessages();
  return (
    <Container className="py-20 sm:py-28">
      <p className="text-xs font-semibold tracking-[0.18em] text-accent uppercase">
        {m.coming.kicker}
      </p>
      <h1 className="mt-4 max-w-2xl font-display text-4xl font-medium tracking-[-0.03em] sm:text-5xl">
        {title}
      </h1>
      <p className="mt-5 max-w-xl text-base leading-relaxed text-muted sm:text-lg">{body}</p>
      {extra ? <p className="mt-4 max-w-xl text-base leading-relaxed text-muted">{extra}</p> : null}
      <div className="mt-10 flex flex-col gap-3 sm:flex-row">
        <Button asChild>
          <Link to="/">
            <ArrowLeft className="size-4" />
            {m.coming.back}
          </Link>
        </Button>
        <Button variant="secondary" asChild>
          <Link to="/" hash="product">
            {m.coming.explore}
          </Link>
        </Button>
      </div>
    </Container>
  );
}
