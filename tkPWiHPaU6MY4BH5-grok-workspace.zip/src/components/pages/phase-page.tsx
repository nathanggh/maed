import { ComingSoon } from "@/components/pages/coming-soon";
import { useMessages } from "@/i18n/provider";

export type PhaseKind =
  | "updates"
  | "careers"
  | "help"
  | "docs"
  | "support"
  | "privacy"
  | "terms";

const COPY: Record<PhaseKind, { title: "updates_title" | "careers_title" | "help_title" | "docs_title" | "support_title" | "privacy_title" | "terms_title"; body: "updates_body" | "careers_body" | "help_body" | "docs_body" | "support_body" | "privacy_body" | "terms_body" }> = {
  updates: { title: "updates_title", body: "updates_body" },
  careers: { title: "careers_title", body: "careers_body" },
  help: { title: "help_title", body: "help_body" },
  docs: { title: "docs_title", body: "docs_body" },
  support: { title: "support_title", body: "support_body" },
  privacy: { title: "privacy_title", body: "privacy_body" },
  terms: { title: "terms_title", body: "terms_body" },
};

export function PhasePage({ kind }: { kind: PhaseKind }) {
  const m = useMessages();
  const copy = COPY[kind];
  return <ComingSoon title={m.coming[copy.title]} body={m.coming[copy.body]} />;
}
