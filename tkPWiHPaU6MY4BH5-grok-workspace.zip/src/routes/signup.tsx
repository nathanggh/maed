import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/pages/coming-soon";
import { useMessages } from "@/i18n/provider";

export const Route = createFileRoute("/signup")({
  component: SignupPage,
  head: () => ({ meta: [{ title: "Get started — MA’ED MENU" }] }),
});

function SignupPage() {
  const m = useMessages();
  return <ComingSoon title={m.coming.signup_title} body={m.coming.signup_body} />;
}
