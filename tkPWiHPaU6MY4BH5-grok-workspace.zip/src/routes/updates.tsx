import { createFileRoute } from "@tanstack/react-router";
import { PhasePage } from "@/components/pages/phase-page";

export const Route = createFileRoute("/updates")({
  component: () => <PhasePage kind="updates" />,
  head: () => ({ meta: [{ title: "Updates — MA’ED MENU" }] }),
});
