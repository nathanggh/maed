import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/pages/coming-soon";
import { useMessages } from "@/i18n/provider";

export const Route = createFileRoute("/login")({
  component: LoginPage,
  head: () => ({ meta: [{ title: "Sign in — MA’ED MENU" }] }),
});

function LoginPage() {
  const m = useMessages();
  return <ComingSoon title={m.coming.login_title} body={m.coming.login_body} />;
}
