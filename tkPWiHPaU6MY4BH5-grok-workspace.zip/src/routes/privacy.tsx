import { createFileRoute } from "@tanstack/react-router";
import { PhasePage } from "@/components/pages/phase-page";

export const Route = createFileRoute("/privacy")({
  component: () => <PhasePage kind="privacy" />,
  head: () => ({ meta: [{ title: "Privacy — MA’ED MENU" }] }),
});
