import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/pages/coming-soon";
import { useMessages } from "@/i18n/provider";

export const Route = createFileRoute("/about")({
  component: AboutPage,
  head: () => ({ meta: [{ title: "About — MA’ED MENU" }] }),
});

function AboutPage() {
  const m = useMessages();
  return <ComingSoon title={m.coming.about_title} body={m.coming.about_body} extra={m.coming.about_p2} />;
}
