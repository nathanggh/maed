import { createFileRoute } from "@tanstack/react-router";
import { LandingPage } from "@/components/landing/landing-page";

export const Route = createFileRoute("/")({
  component: Home,
  head: () => ({
    meta: [
      { title: "MA’ED MENU — Hospitality operations infrastructure" },
      {
        name: "description",
        content:
          "Professional digital infrastructure for restaurants, hotels, cafés, and lounges. Manage menus, staff, orders, payments, and branches.",
      },
    ],
  }),
});

function Home() {
  return <LandingPage />;
}
