import { createFileRoute } from "@tanstack/react-router";
import { PhasePage } from "@/components/pages/phase-page";

export const Route = createFileRoute("/support")({
  component: () => <PhasePage kind="support" />,
  head: () => ({ meta: [{ title: "Support — MA’ED MENU" }] }),
});
