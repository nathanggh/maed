import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Container } from "@/components/layout/container";
import { Button } from "@/components/ui/button";
import { useMessages } from "@/i18n/provider";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/pricing")({
  component: PricingPage,
  head: () => ({ meta: [{ title: "Pricing — MA’ED MENU" }] }),
});

function PricingPage() {
  const m = useMessages();
  const plans = [
    { name: m.pricing.trial, meta: m.pricing.trial_meta, body: m.pricing.trial_body, featured: true },
    { name: m.pricing.pro, meta: "—", body: m.pricing.coming, featured: false },
    { name: m.pricing.pro_plus, meta: "—", body: m.pricing.coming, featured: false },
    { name: m.pricing.premium, meta: "—", body: m.pricing.coming, featured: false },
    { name: m.pricing.enterprise, meta: "—", body: m.pricing.coming, featured: false },
  ];

  return (
    <Container className="py-16 sm:py-24">
      <p className="text-xs font-semibold tracking-[0.18em] text-accent uppercase">
        {m.pricing.eyebrow}
      </p>
      <h1 className="mt-4 max-w-2xl font-display text-4xl font-medium tracking-[-0.03em] sm:text-5xl">
        {m.pricing.title}
      </h1>
      <p className="mt-5 max-w-xl text-lg text-muted">{m.pricing.body}</p>
      <ul className="mt-12 grid gap-4 lg:grid-cols-5">
        {plans.map((plan) => (
          <li
            key={plan.name}
            className={cn(
              "rounded-xl p-5",
              plan.featured ? "bg-primary text-primary-foreground shadow-lift" : "bg-surface shadow-card",
            )}
          >
            <p className="text-sm font-semibold">{plan.name}</p>
            <p className="mt-2 font-display text-2xl font-medium">{plan.meta}</p>
            <p
              className={cn(
                "mt-3 text-sm leading-relaxed",
                plan.featured ? "text-primary-foreground/80" : "text-muted",
              )}
            >
              {plan.body}
            </p>
          </li>
        ))}
      </ul>
      <p className="mt-8 text-sm text-subtle">{m.pricing.coming}</p>
      <div className="mt-8">
        <Button asChild>
          <Link to="/signup">
            {m.cta.primary}
            <ArrowRight className="size-4" />
          </Link>
        </Button>
      </div>
    </Container>
  );
}
