import { createFileRoute } from "@tanstack/react-router";
import { PhasePage } from "@/components/pages/phase-page";

export const Route = createFileRoute("/docs")({
  component: () => <PhasePage kind="docs" />,
  head: () => ({ meta: [{ title: "Documentation — MA’ED MENU" }] }),
});
