import { createFileRoute } from "@tanstack/react-router";
import { PhasePage } from "@/components/pages/phase-page";

export const Route = createFileRoute("/terms")({
  component: () => <PhasePage kind="terms" />,
  head: () => ({ meta: [{ title: "Terms — MA’ED MENU" }] }),
});
