import { createFileRoute } from "@tanstack/react-router";
import { PhasePage } from "@/components/pages/phase-page";

export const Route = createFileRoute("/careers")({
  component: () => <PhasePage kind="careers" />,
  head: () => ({ meta: [{ title: "Careers — MA’ED MENU" }] }),
});
