import { createFileRoute } from "@tanstack/react-router";
import { PhasePage } from "@/components/pages/phase-page";

export const Route = createFileRoute("/help")({
  component: () => <PhasePage kind="help" />,
  head: () => ({ meta: [{ title: "Help Center — MA’ED MENU" }] }),
});
