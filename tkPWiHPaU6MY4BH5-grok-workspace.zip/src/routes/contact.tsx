import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/pages/coming-soon";
import { useMessages } from "@/i18n/provider";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
  head: () => ({ meta: [{ title: "Contact — MA’ED MENU" }] }),
});

function ContactPage() {
  const m = useMessages();
  return <ComingSoon title={m.coming.contact_title} body={m.coming.contact_body} />;
}
