import { am } from "./am";
import { en, type Messages } from "./en";
import type { Locale } from "@/lib/storage";

export type { Messages };
export type { Locale };

export const dictionaries: Record<Locale, Messages> = {
  en,
  am,
};

export const locales: Locale[] = ["en", "am"];
