export const THEME_STORAGE_KEY = "maed-theme";
export const LANG_STORAGE_KEY = "maed-lang";

export type ThemePreference = "light" | "dark" | "system";
export type ResolvedTheme = "light" | "dark";
export type Locale = "en" | "am";

export function readStorage(key: string): string | null {
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

export function writeStorage(key: string, value: string) {
  try {
    window.localStorage.setItem(key, value);
  } catch {
    /* private mode / blocked storage */
  }
}

export function isLocale(value: string | null): value is Locale {
  return value === "en" || value === "am";
}

export function isThemePreference(value: string | null): value is ThemePreference {
  return value === "light" || value === "dark" || value === "system";
}

export function resolveTheme(preference: ThemePreference, systemDark: boolean): ResolvedTheme {
  if (preference === "system") return systemDark ? "dark" : "light";
  return preference;
}

export function applyDocumentTheme(resolved: ResolvedTheme, preference: ThemePreference) {
  const root = document.documentElement;
  root.dataset.theme = resolved;
  root.dataset.themePref = preference;
  root.style.colorScheme = resolved;
}

export function applyDocumentLocale(locale: Locale) {
  document.documentElement.lang = locale;
}
