//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-dOn30nhs.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/careers",
			"/contact",
			"/docs",
			"/help",
			"/login",
			"/pricing",
			"/privacy",
			"/signup",
			"/support",
			"/terms",
			"/updates"
		],
		preloads: ["/assets/index-DfoNDStn.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DfoNDStn.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-tOO0hSUD.js", "/assets/arrow-right-CHYP7PWd.js"]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-BNnMWqtO.js", "/assets/coming-soon-BOpqKCxr.js"]
	},
	"/careers": {
		filePath: "/workspace/src/routes/careers.tsx",
		children: void 0,
		preloads: ["/assets/careers-RQ8oLsWK.js", "/assets/phase-page-Copwvah5.js"]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-GNAalAoI.js", "/assets/coming-soon-BOpqKCxr.js"]
	},
	"/docs": {
		filePath: "/workspace/src/routes/docs.tsx",
		children: void 0,
		preloads: ["/assets/docs-DXaG0RmV.js", "/assets/phase-page-Copwvah5.js"]
	},
	"/help": {
		filePath: "/workspace/src/routes/help.tsx",
		children: void 0,
		preloads: ["/assets/help-BtalSpVD.js", "/assets/phase-page-Copwvah5.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-C0jCUAgd.js", "/assets/coming-soon-BOpqKCxr.js"]
	},
	"/pricing": {
		filePath: "/workspace/src/routes/pricing.tsx",
		children: void 0,
		preloads: ["/assets/pricing-DZEbxvns.js", "/assets/arrow-right-CHYP7PWd.js"]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-hk5Uo1CQ.js", "/assets/phase-page-Copwvah5.js"]
	},
	"/signup": {
		filePath: "/workspace/src/routes/signup.tsx",
		children: void 0,
		preloads: ["/assets/signup-B18wxztB.js", "/assets/coming-soon-BOpqKCxr.js"]
	},
	"/support": {
		filePath: "/workspace/src/routes/support.tsx",
		children: void 0,
		preloads: ["/assets/support-sC94MeSG.js", "/assets/phase-page-Copwvah5.js"]
	},
	"/terms": {
		filePath: "/workspace/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-B7crm8Pe.js", "/assets/phase-page-Copwvah5.js"]
	},
	"/updates": {
		filePath: "/workspace/src/routes/updates.tsx",
		children: void 0,
		preloads: ["/assets/updates-C_P5_uPP.js", "/assets/phase-page-Copwvah5.js"]
	}
} });
//#endregion
export { tsrStartManifest };
