import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as useMessages } from "./router-DmaOi4Rh.mjs";
import { t as ComingSoon } from "./coming-soon-D8VrRrg2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/phase-page-D9Sbb-lK.js
var import_jsx_runtime = require_jsx_runtime();
var COPY = {
	updates: {
		title: "updates_title",
		body: "updates_body"
	},
	careers: {
		title: "careers_title",
		body: "careers_body"
	},
	help: {
		title: "help_title",
		body: "help_body"
	},
	docs: {
		title: "docs_title",
		body: "docs_body"
	},
	support: {
		title: "support_title",
		body: "support_body"
	},
	privacy: {
		title: "privacy_title",
		body: "privacy_body"
	},
	terms: {
		title: "terms_title",
		body: "terms_body"
	}
};
function PhasePage({ kind }) {
	const m = useMessages();
	const copy = COPY[kind];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComingSoon, {
		title: m.coming[copy.title],
		body: m.coming[copy.body]
	});
}
//#endregion
export { PhasePage as t };
