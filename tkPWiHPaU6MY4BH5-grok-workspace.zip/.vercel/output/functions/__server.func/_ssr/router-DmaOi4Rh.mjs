import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as createRootRoute, b as require_jsx_runtime, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as TriangleAlert, d as Monitor, f as Menu, l as Sun, t as X, u as Moon } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DmaOi4Rh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-3 bg-background px-6 text-center text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-danger",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 1.75
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-medium",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-2 text-sm font-medium text-foreground underline-offset-4 hover:underline",
				children: "Back to home"
			})
		]
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[60vh] flex-col items-center justify-center gap-3 px-6 py-20 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-[0.18em] text-accent uppercase",
				children: "404"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-medium",
				children: "This page is not here."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm text-muted",
				children: "The address does not match a published MA’ED MENU page."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-2 text-sm font-medium text-foreground underline-offset-4 hover:underline",
				children: "Back to home"
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var dictionaries = {
	en: {
		meta: {
			title: "MA’ED MENU — Hospitality operations infrastructure",
			description: "Professional digital infrastructure for restaurants, hotels, cafés, and lounges. Manage menus, staff, orders, payments, and branches from one workspace."
		},
		brand: {
			name: "MA’ED MENU",
			maed: "MA’ED",
			menu: "MENU",
			mark_label: "MA’ED MENU mark"
		},
		a11y: {
			skip: "Skip to content",
			open_menu: "Open menu",
			close_menu: "Close menu",
			language: "Language",
			theme: "Appearance",
			primary_nav: "Primary",
			footer_nav: "Footer"
		},
		nav: {
			product: "Product",
			solutions: "Solutions",
			pricing: "Pricing",
			resources: "Resources",
			sign_in: "Sign in",
			get_started: "Get started"
		},
		theme: {
			light: "Light",
			dark: "Dark",
			system: "System"
		},
		language: {
			en: "English",
			am: "አማርኛ"
		},
		hero: {
			eyebrow: "Hospitality operations",
			title: "Hospitality operations, designed as infrastructure.",
			subtitle: "MA’ED MENU is a professional workspace for restaurants, hotels, cafés, and lounges. Manage menus, staff, orders, payments, and branches — built around how service actually happens.",
			cta_primary: "Get started",
			cta_secondary: "Explore MA’ED MENU",
			preview_label: "Product preview",
			preview_sample: "Sample data",
			preview_today: "Today",
			metric_revenue: "Revenue",
			metric_orders: "Orders",
			metric_pending: "Pending",
			metric_verified: "Verified",
			staff_activity: "Staff activity",
			menu_activity: "Menu activity",
			currency: "ETB"
		},
		trust: {
			eyebrow: "Who it is for",
			title: "Designed for hospitality businesses that take operations seriously.",
			body: "MA’ED MENU is not a customer food-ordering marketplace. It is business-side infrastructure for the people who run the room.",
			restaurants: "Restaurants",
			hotels: "Hotels",
			cafes: "Cafés",
			lounges: "Lounges",
			hospitality: "Hospitality",
			restaurants_body: "Floor service, kitchen tickets, and a verified record of the night.",
			hotels_body: "F&B across outlets, with one owner view of every workspace.",
			cafes_body: "Fast counters, clear menus, and payments that stay accountable.",
			lounges_body: "Evening service, tab discipline, and staff who can move quickly.",
			hospitality_body: "Any food-service business that needs a calm operating layer."
		},
		value: {
			eyebrow: "Capabilities",
			title: "One workspace. The full operating day.",
			body: "Each capability is a real part of how a hospitality business runs — not a marketing label.",
			digital_menu: "Digital menu",
			digital_menu_body: "Manage food and beverage items, categories, and prices with a structure staff can actually use.",
			staff: "Staff",
			staff_body: "Give owners and managers controlled access. Roles stay explicit; permissions stay with the business.",
			orders: "Orders",
			orders_body: "Authorized staff record verbal customer orders quickly, without turning the floor into a kiosk.",
			payments: "Payments",
			payments_body: "Track cash and digital payments with a verification workflow the owner can trust.",
			branches: "Branches",
			branches_body: "Run multiple branches from one business account, each with its own operating record.",
			insights: "Insights",
			insights_body: "See revenue, orders, payment mix, and staff activity as a clear picture of the business."
		},
		how: {
			eyebrow: "How it works",
			title: "Four steps from an empty workspace to a running floor.",
			body: "The path is intentionally short. Complexity belongs in the operation, not in getting started.",
			step1_title: "Create your business",
			step1_body: "Open a business account and set the profile your staff will work inside.",
			step2_title: "Build your menu",
			step2_body: "Add items, categories, and prices so every order starts from the same source.",
			step3_title: "Let your staff operate",
			step3_body: "Waiters, cashiers, and managers work with the permissions you assign.",
			step4_title: "Track orders and payments",
			step4_body: "The day becomes a record: what was ordered, what was paid, and what still needs verification."
		},
		use_cases: {
			eyebrow: "Solutions",
			title: "The same infrastructure, shaped to the room.",
			body: "Hospitality is not one format. MA’ED MENU is designed to hold restaurants, cafés, hotels, lounges, and other food businesses without forcing them into the same script.",
			restaurants: "Restaurants",
			cafes: "Cafés",
			hotels: "Hotels",
			lounges: "Lounges",
			other: "Other food businesses",
			restaurants_lead: "Service that starts with a conversation, not a screen.",
			restaurants_body: "Guests order verbally. Staff capture the ticket, the kitchen sees a clean record, and payment closes with verification — not a pile of paper at the end of the night.",
			restaurants_c1: "Course-aware menus and prices",
			restaurants_c2: "Waiter-led order capture",
			restaurants_c3: "Cashier verification",
			cafes_lead: "A counter that stays fast when the queue does not.",
			cafes_body: "Short menus, repeat items, mixed payments. The workspace keeps the line moving while still leaving the owner a trustworthy close.",
			cafes_c1: "Compact menus and modifiers",
			cafes_c2: "Quick ticket entry",
			cafes_c3: "Telebirr, cash, and transfer in one record",
			hotels_lead: "Several outlets. One owner view.",
			hotels_body: "A hotel is rarely a single kitchen. Each outlet keeps its own workspace; the owner still sees the group without mixing the books.",
			hotels_c1: "Outlet-level workspaces",
			hotels_c2: "Shared ownership, separate records",
			hotels_c3: "F&B reporting across branches",
			lounges_lead: "Evening service with a quieter back office.",
			lounges_body: "Tabs, late tickets, and mixed tenders need discipline. Staff record what happened; authorized roles confirm what was paid.",
			lounges_c1: "Floor-first order flow",
			lounges_c2: "Payment proof for digital tenders",
			lounges_c3: "Owner visibility after close",
			other_lead: "If you serve food, you still need an operating record.",
			other_body: "Caterers, bakeries, canteens, and independent kitchens can run the same menu, staff, order, and payment discipline without a custom system.",
			other_c1: "Menu and price control",
			other_c2: "Staff roles that fit a small team",
			other_c3: "A single source for the day’s activity"
		},
		operations: {
			eyebrow: "Operational advantage",
			title: "The guest still speaks. The business finally has a record.",
			body: "MA’ED MENU is not only a digital menu. It is how the house keeps an operational memory of the day.",
			step_order: "Customer orders verbally",
			step_record: "Staff records the order",
			step_total: "The system calculates the total",
			step_pay: "Payment is recorded",
			step_proof: "Digital payment proof can be submitted",
			step_verify: "Cashier or owner verifies it",
			step_owner: "The owner sees the resulting activity",
			note: "This is the operating philosophy. The live workflow ships in a later phase."
		},
		offline: {
			eyebrow: "Offline-first direction",
			title: "Service should not stop because the network did.",
			body: "Hospitality does not pause for a weak connection. MA’ED MENU is designed so the floor can keep recording work, then reconcile when the line returns.",
			online: "Online",
			offline: "Offline",
			order: "Order",
			payment: "Payment",
			sync: "Sync",
			order_saved: "Order saved locally",
			payment_recorded: "Payment recorded",
			connection_returns: "Connection returns",
			secure_sync: "Secure sync",
			note: "Offline operation is a product direction, not a claim of finished coverage."
		},
		multi: {
			eyebrow: "Multi-business",
			title: "One owner. Several businesses. Each with its own workspace.",
			body: "A hospitality group is not a single counter. MA’ED MENU is designed so an owner can hold hotels, cafés, and restaurants as separate businesses — and branches under each — without collapsing them into one list.",
			owner: "Owner",
			hotel: "ABC Hotel",
			hotel_bole: "Bole Branch",
			hotel_airport: "Airport Branch",
			cafe: "ABC Café",
			restaurant: "ABC Restaurant",
			workspace: "Private business workspace",
			workspace_example: "abchotel.maedmenu.com",
			workspace_note: "This is not the public customer menu. It is the private workspace for the business and its staff.",
			note: "The workspace model is shown here as product direction. It is not live in this phase."
		},
		staff: {
			eyebrow: "Staff workflow",
			title: "Owners decide who can do what.",
			body: "The floor needs speed. The business needs control. Roles make that possible without turning every action into a meeting.",
			owner: "Owner",
			admin: "Administrator / Manager",
			cashier: "Cashier",
			waiter: "Waiter",
			owner_body: "Sees the whole business. Assigns access. Verifies what must be verified.",
			admin_body: "Runs the house day to day, within the permissions the owner grants.",
			cashier_body: "Closes payments and confirms digital proof before it becomes a record.",
			waiter_body: "Captures verbal orders and payment proof without inheriting the whole system.",
			note: "Staff management is a later phase. This is the model the product is built around."
		},
		payments: {
			eyebrow: "Payment workflow",
			title: "A payment is not finished until someone accountable says it is.",
			body: "Cash, Telebirr, bank transfer, and other configured methods all land in the same sequence — so the close of day is a verification, not a reconstruction.",
			order: "Order",
			unpaid: "Unpaid",
			submitted: "Payment submitted",
			pending: "Pending verification",
			verified: "Verified",
			methods_label: "Methods",
			cash: "Cash",
			telebirr: "Telebirr",
			bank: "Bank transfer",
			other: "Other configured methods",
			proof_title: "Digital payment proof",
			proof_body: "A waiter can capture proof. A cashier or authorized staff member verifies it. That is how trust is built into the record.",
			note: "The live payment system is not part of this phase. The sequence above is the product model."
		},
		analytics: {
			eyebrow: "Analytics",
			title: "The day, readable.",
			body: "Owners should not have to reconstruct the business from memory. The workspace is designed to surface revenue, orders, tender mix, popular items, and staff activity as a calm picture — not a noisy board.",
			sample: "Demonstration data",
			revenue: "Revenue",
			orders: "Orders",
			methods: "Payment methods",
			popular: "Popular menu items",
			staff: "Staff activity",
			trends: "Seven-day trend",
			cash: "Cash",
			telebirr: "Telebirr",
			bank: "Bank",
			items: "Items",
			tickets: "Tickets"
		},
		pricing: {
			eyebrow: "Pricing",
			title: "Choose a plan that grows with your business.",
			body: "Start with a trial. Move to the plan that matches how many rooms, people, and branches you actually run.",
			explore: "Explore plans",
			trial: "Free trial",
			trial_meta: "14 days",
			trial_body: "Open a business workspace and see whether the operating model fits the house.",
			pro: "Pro",
			pro_plus: "Pro Plus",
			premium: "Premium",
			enterprise: "Enterprise",
			coming: "Plan details will be published as registration opens. No prices are listed yet.",
			cta: "Explore plans"
		},
		cta: {
			title: "Your business deserves better tools.",
			body: "If the floor still runs on paper, memory, and unverified transfers, there is a quieter way to keep the record.",
			primary: "Start your 14-day trial",
			secondary: "Talk to us"
		},
		footer: {
			product: "Product",
			features: "Features",
			pricing: "Pricing",
			updates: "Updates",
			solutions: "Solutions",
			restaurants: "Restaurants",
			hotels: "Hotels",
			cafes: "Cafés",
			hospitality: "Hospitality",
			company: "Company",
			about: "About",
			contact: "Contact",
			careers: "Careers",
			resources: "Resources",
			help: "Help Center",
			docs: "Documentation",
			support: "Support",
			legal: "Legal",
			privacy: "Privacy",
			terms: "Terms",
			copyright: "© MA’ED MENU",
			tagline: "Professional digital infrastructure for hospitality businesses."
		},
		coming: {
			kicker: "Later phase",
			back: "Back to home",
			explore: "Explore the product",
			signup_title: "Business registration is being prepared.",
			signup_body: "Get started will open a business account in a later phase. Today you can read how MA’ED MENU is designed to run the house.",
			login_title: "Sign in is not open yet.",
			login_body: "Staff and owner sign-in will arrive with business accounts. No credentials are issued in this phase.",
			pricing_title: "Plans, without invented prices.",
			pricing_body: "MA’ED MENU will offer a 14-day free trial, then Pro, Pro Plus, Premium, and Enterprise. Final pricing will be published when registration opens.",
			about_title: "Built as infrastructure for hospitality.",
			about_body: "MA’ED MENU is a professional operations layer for restaurants, hotels, cafés, lounges, and other food-service businesses. It starts in Ethiopia, with a design that is meant to travel.",
			about_p2: "The first product is business-side. Guests may still order verbally from a printed menu. The system exists so the house can record orders, payments, staff, menus, and branches with discipline.",
			contact_title: "A conversation, when the channel is ready.",
			contact_body: "Talk to us will open a real contact path in a later phase. We are not publishing a placeholder address or a form that goes nowhere.",
			privacy_title: "Privacy",
			privacy_body: "A full privacy policy will be published before accounts open. This phase does not collect business or personal account data.",
			terms_title: "Terms",
			terms_body: "Terms of use will be published with registration. This public site is an introduction to the product, not an account agreement.",
			updates_title: "Updates",
			updates_body: "Product updates will be listed here as MA’ED MENU opens later phases.",
			careers_title: "Careers",
			careers_body: "There are no open roles published yet. When there are, they will appear here.",
			help_title: "Help Center",
			help_body: "Help articles will ship with the operating product. This phase is the public introduction.",
			docs_title: "Documentation",
			docs_body: "Operator documentation will be written against the live workspace, not against a mock.",
			support_title: "Support",
			support_body: "Support channels will open with business accounts.",
			features_title: "Features",
			features_body: "The product capabilities are introduced on the home page. The live workspace follows in later phases."
		},
		demo: {
			sample: "Sample",
			waiter: "Waiter",
			cashier: "Cashier",
			manager: "Manager",
			item_doro: "Doro Wot",
			item_tibs: "Beef Tibs",
			item_shiro: "Shiro",
			item_chechebsa: "Chechebsa",
			item_coffee: "Iced coffee",
			staff_hana: "Hana Bekele",
			staff_dawit: "Dawit Tesfaye",
			staff_makeda: "Makeda Alemu",
			staff_yonas: "Yonas Hailu",
			table: "Table",
			open_tickets: "Open tickets",
			verified_today: "Verified today"
		}
	},
	am: {
		meta: {
			title: "MA’ED MENU — የእንግዳ ተቀባይ ንግድ የስራ መሠረት",
			description: "ለሬስቶራንት፣ ሆቴል፣ ካፌ እና ላውንጅ የሚሆን የሙያ ዲጂታል መሠረተ ልማት። ሜኑ፣ ሰራተኛ፣ ትዕዛዝ፣ ክፍያ እና ቅርንጫፍ ከአንድ የስራ ቦታ ያስተዳድሩ።"
		},
		brand: {
			name: "MA’ED MENU",
			maed: "MA’ED",
			menu: "MENU",
			mark_label: "የMA’ED MENU ምልክት"
		},
		a11y: {
			skip: "ወደ ይዘት ይዝለሉ",
			open_menu: "ሜኑ ክፈት",
			close_menu: "ሜኑ ዝጋ",
			language: "ቋንቋ",
			theme: "ገጽታ",
			primary_nav: "ዋና ዳሰሳ",
			footer_nav: "የግርጌ ዳሰሳ"
		},
		nav: {
			product: "ምርት",
			solutions: "መፍትሄዎች",
			pricing: "ዋጋ",
			resources: "መረጃ",
			sign_in: "ይግቡ",
			get_started: "ይጀምሩ"
		},
		theme: {
			light: "ብሩህ",
			dark: "ጨለማ",
			system: "ስርዓት"
		},
		language: {
			en: "English",
			am: "አማርኛ"
		},
		hero: {
			eyebrow: "የእንግዳ ተቀባይ ሥራ",
			title: "የእንግዳ ተቀባይ ሥራ እንደ መሠረተ ልማት የተገነባ።",
			subtitle: "MA’ED MENU ለሬስቶራንት፣ ሆቴል፣ ካፌ እና ላውንጅ የሚሆን የሙያ የስራ ቦታ ነው። ሜኑ፣ ሰራተኛ፣ ትዕዛዝ፣ ክፍያ እና ቅርንጫፍ — አገልግሎት በሚሰጥበት መንገድ ተገንብቷል።",
			cta_primary: "ይጀምሩ",
			cta_secondary: "MA’ED MENUን ይመልከቱ",
			preview_label: "የምርት ቅድመ እይታ",
			preview_sample: "ናሙና መረጃ",
			preview_today: "ዛሬ",
			metric_revenue: "ገቢ",
			metric_orders: "ትዕዛዞች",
			metric_pending: "በመጠባበቅ",
			metric_verified: "የተረጋገጠ",
			staff_activity: "የሰራተኛ እንቅስቃሴ",
			menu_activity: "የሜኑ እንቅስቃሴ",
			currency: "ብር"
		},
		trust: {
			eyebrow: "ለማን ነው",
			title: "ሥራን በቁም ነገር ለሚወስዱ የእንግዳ ተቀባይ ንግዶች የተሰራ።",
			body: "MA’ED MENU የደንበኛ የምግብ ማዘዣ ገበያ አይደለም። ክፍሉን ለሚያስኬዱ ሰዎች የሚሆን የንግድ መሠረተ ልማት ነው።",
			restaurants: "ሬስቶራንቶች",
			hotels: "ሆቴሎች",
			cafes: "ካፌዎች",
			lounges: "ላውንጆች",
			hospitality: "እንግዳ ተቀባይ ንግድ",
			restaurants_body: "የአዳራሽ አገልግሎት፣ የኩሽና ትኬት፣ እና የሌሊቱ የተረጋገጠ መዝገብ።",
			hotels_body: "በብዙ መሸጫ ቦታዎች የምግብና መጠጥ አገልግሎት፣ ለባለቤቱ አንድ ግልጽ እይታ።",
			cafes_body: "ፈጣን ካውንተር፣ ግልጽ ሜኑ፣ እና ተጠያቂነት ያለው ክፍያ።",
			lounges_body: "የማታ አገልግሎት፣ የሂሳብ ሥርዓት፣ እና በፍጥነት የሚንቀሳቀስ ሰራተኛ።",
			hospitality_body: "የተረጋጋ የስራ ሥርዓት የሚያስፈልገው ማንኛውም የምግብ አገልግሎት ንግድ።"
		},
		value: {
			eyebrow: "ችሎታዎች",
			title: "አንድ የስራ ቦታ። ሙሉ የዕለት ሥራ።",
			body: "እያንዳንዱ ችሎታ የእንግዳ ተቀባይ ንግድ እንዴት እንደሚሠራ የሚያሳይ ነው — የማስታወቂያ ቃል አይደለም።",
			digital_menu: "ዲጂታል ሜኑ",
			digital_menu_body: "የምግብና መጠጥ ዝርዝር፣ ምድቦች እና ዋጋዎችን ሰራተኛ በትክክል የሚጠቀምበት አወቃቀር ያስተዳድሩ።",
			staff: "ሰራተኛ",
			staff_body: "ለባለቤቶችና አስተዳዳሪዎች ቁጥጥር ያለው መዳረሻ ይስጡ። ሚናዎች ግልጽ፣ ፈቃዶች ከንግዱ ጋር ይቀራሉ።",
			orders: "ትዕዛዞች",
			orders_body: "ፈቃድ ያለው ሰራተኛ የደንበኛን የቃል ትዕዛዝ በፍጥነት ይመዘግባል — አዳራሹን ኪዮስክ ሳያደርግ።",
			payments: "ክፍያዎች",
			payments_body: "የጥሬ ገንዘብና ዲጂታል ክፍያዎችን ባለቤቱ የሚያምነው የማረጋገጫ ሂደት ያስከትሉ።",
			branches: "ቅርንጫፎች",
			branches_body: "ብዙ ቅርንጫፎችን ከአንድ የንግድ መለያ ያስኬዱ፣ እያንዳንዱ የራሱ የስራ መዝገብ ይኖረዋል።",
			insights: "ትንታኔ",
			insights_body: "ገቢ፣ ትዕዛዝ፣ የክፍያ ድብልቅ እና የሰራተኛ እንቅስቃሴን እንደ ግልጽ የንግድ ምስል ይመልከቱ።"
		},
		how: {
			eyebrow: "እንዴት እንደሚሠራ",
			title: "ከባዶ የስራ ቦታ እስከ ሥራ ላይ ያለ አዳራሽ — አራት ደረጃዎች።",
			body: "መንገዱ በአጭሩ ተይዟል። ውስብስብነቱ በሥራው ውስጥ ነው እንጂ በመጀመር ላይ አይደለም።",
			step1_title: "ንግድዎን ይፍጠሩ",
			step1_body: "የንግድ መለያ ይክፈቱ እና ሰራተኛዎ የሚሠራበትን መገለጫ ያዘጋጁ።",
			step2_title: "ሜኑዎን ይገንቡ",
			step2_body: "እቃዎችን፣ ምድቦችን እና ዋጋዎችን ያክሉ ስለዚህ እያንዳንዱ ትዕዛዝ ከአንድ ምንጭ ይጀምራል።",
			step3_title: "ሰራተኛዎ እንዲሠራ ያድርጉ",
			step3_body: "አስተናጋጆች፣ ገንዘብ ተቀባዮች እና አስተዳዳሪዎች እርስዎ በሰጡት ፈቃድ ይሠራሉ።",
			step4_title: "ትዕዛዝና ክፍያን ይከታተሉ",
			step4_body: "ቀኑ መዝገብ ይሆናል፦ ምን እንደታዘዘ፣ ምን እንደተከፈለ፣ እና ምን ማረጋገጫ እንደሚያስፈልገው።"
		},
		use_cases: {
			eyebrow: "መፍትሄዎች",
			title: "አንድ መሠረተ ልማት፣ ለክፍሉ የተስተካከለ።",
			body: "እንግዳ ተቀባይነት አንድ ቅርጽ አይደለም። MA’ED MENU ሬስቶራንት፣ ካፌ፣ ሆቴል፣ ላውንጅ እና ሌሎች የምግብ ንግዶችን በአንድ ጽሑፍ ሳይጨምቃቸው ይይዛል።",
			restaurants: "ሬስቶራንቶች",
			cafes: "ካፌዎች",
			hotels: "ሆቴሎች",
			lounges: "ላውንጆች",
			other: "ሌሎች የምግብ ንግዶች",
			restaurants_lead: "አገልግሎት ከውይይት ይጀምራል እንጂ ከማያ ገጽ አይደለም።",
			restaurants_body: "እንግዶች በቃል ያዛሉ። ሰራተኛው ትኬቱን ይይዛል፣ ኩሽናው ግልጽ መዝገብ ያያል፣ ክፍያውም በማረጋገጫ ይዘጋል — በሌሊቱ መጨረሻ የወረቀት ክምር ሳይሆን።",
			restaurants_c1: "በኮርስ የተደራጀ ሜኑና ዋጋ",
			restaurants_c2: "በአስተናጋጅ የሚመራ የትዕዛዝ መያዝ",
			restaurants_c3: "የገንዘብ ተቀባይ ማረጋገጫ",
			cafes_lead: "ረድፉ ሲረዝም ካውንተሩ ፈጣን ሆኖ የሚቆይ።",
			cafes_body: "አጭር ሜኑ፣ ተደጋጋሚ እቃዎች፣ የተቀላቀለ ክፍያ። የስራ ቦታው መስመሩን እያንቀሳቀሰ ለባለቤቱ የሚታመን መዝጊያ ይተዋል።",
			cafes_c1: "አጭር ሜኑና ማሻሻያዎች",
			cafes_c2: "ፈጣን የትኬት መግቢያ",
			cafes_c3: "ቴሌብር፣ ጥሬ ገንዘብ እና ማስተላለፍ በአንድ መዝገብ",
			hotels_lead: "ብዙ መሸጫ ቦታዎች። አንድ የባለቤት እይታ።",
			hotels_body: "ሆቴል አንድ ኩሽና ብቻ አይደለም። እያንዳንዱ መሸጫ የራሱ የስራ ቦታ አለው፤ ባለቤቱ ግን መጻሕፍቱን ሳያደባልቅ ቡድኑን ያያል።",
			hotels_c1: "በመሸጫ ደረጃ የስራ ቦታዎች",
			hotels_c2: "የጋራ ባለቤትነት፣ የተለየ መዝገብ",
			hotels_c3: "በቅርንጫፎች ላይ የምግብና መጠጥ ሪፖርት",
			lounges_lead: "የማታ አገልግሎት ከተረጋጋ የኋላ ቢሮ ጋር።",
			lounges_body: "ሂሳቦች፣ የዘገየ ትኬቶች እና የተቀላቀለ ክፍያ ሥርዓት ይፈልጋሉ። ሰራተኛው የሆነውን ይመዘግባል፤ ፈቃድ ያለው ሚና የተከፈለውን ያረጋግጣል።",
			lounges_c1: "አዳራሽ-ቀዳሚ የትዕዛዝ ፍሰት",
			lounges_c2: "ለዲጂታል ክፍያ የማስረጃ ማስረጃ",
			lounges_c3: "ከመዝጋት በኋላ የባለቤት እይታ",
			other_lead: "ምግብ የሚያቀርቡ ከሆነ የስራ መዝገብ ያስፈልግዎታል።",
			other_body: "ከተሪዎች፣ ቤከሪዎች፣ ካንቲኖች እና ነጻ ኩሽናዎች ያለ ልዩ ሥርዓት ተመሳሳይ የሜኑ፣ ሰራተኛ፣ ትዕዛዝ እና ክፍያ ሥርዓት ሊያስኬዱ ይችላሉ።",
			other_c1: "የሜኑና ዋጋ ቁጥጥር",
			other_c2: "ለትንሽ ቡድን የሚስማሙ የሰራተኛ ሚናዎች",
			other_c3: "ለቀኑ እንቅስቃሴ አንድ ምንጭ"
		},
		operations: {
			eyebrow: "የስራ ጥቅም",
			title: "እንግዳው አሁንም ይናገራል። ንግዱ በመጨረሻ መዝገብ አለው።",
			body: "MA’ED MENU ዲጂታል ሜኑ ብቻ አይደለም። ቤቱ የቀኑን የስራ ትውስታ የሚይዝበት መንገድ ነው።",
			step_order: "ደንበኛ በቃል ያዛል",
			step_record: "ሰራተኛ ትዕዛዙን ይመዘግባል",
			step_total: "ሥርዓቱ ጠቅላላውን ያሰላል",
			step_pay: "ክፍያ ይመዘገባል",
			step_proof: "የዲጂታል ክፍያ ማስረጃ ሊቀርብ ይችላል",
			step_verify: "ገንዘብ ተቀባይ ወይም ባለቤት ያረጋግጣል",
			step_owner: "ባለቤቱ የተፈጠረውን እንቅስቃሴ ያያል",
			note: "ይህ የስራ ፍልስፍና ነው። የቀጥታ የስራ ፍሰቱ በኋላ ደረጃ ይመጣል።"
		},
		offline: {
			eyebrow: "ከመስመር ውጭ ቅድሚያ",
			title: "መረብ ስለዳከመ አገልግሎት አይቁም።",
			body: "እንግዳ ተቀባይነት ለደካማ ግንኙነት አይቆምም። MA’ED MENU አዳራሹ ሥራውን መመዝገብ እንዲቀጥል፣ መስመሩ ሲመለስም እንዲስተካከል ተብሎ የተገነባ ነው።",
			online: "መስመር ላይ",
			offline: "ከመስመር ውጭ",
			order: "ትዕዛዝ",
			payment: "ክፍያ",
			sync: "ማስማማት",
			order_saved: "ትዕዛዝ በአካባቢ ተቀምጧል",
			payment_recorded: "ክፍያ ተመዝግቧል",
			connection_returns: "ግንኙነት ይመለሳል",
			secure_sync: "ደህንነቱ የተጠበቀ ማስማማት",
			note: "ከመስመር ውጭ መሥራት የምርት አቅጣጫ ነው እንጂ የተጠናቀቀ ሽፋን አይደለም።"
		},
		multi: {
			eyebrow: "ብዙ ንግድ",
			title: "አንድ ባለቤት። ብዙ ንግድ። እያንዳንዱ የራሱ የስራ ቦታ።",
			body: "የእንግዳ ተቀባይ ቡድን አንድ ካውንተር አይደለም። MA’ED MENU ባለቤት ሆቴሎችን፣ ካፌዎችን እና ሬስቶራንቶችን እንደ የተለየ ንግድ — ከዚያም ቅርንጫፎችን ከእያንዳንዱ ሥር — ሳያደባልቃቸው እንዲይዝ ተብሎ የተገነባ ነው።",
			owner: "ባለቤት",
			hotel: "ABC ሆቴል",
			hotel_bole: "የቦሌ ቅርንጫፍ",
			hotel_airport: "የአየር ማረፊያ ቅርንጫፍ",
			cafe: "ABC ካፌ",
			restaurant: "ABC ሬስቶራንት",
			workspace: "የግል የንግድ የስራ ቦታ",
			workspace_example: "abchotel.maedmenu.com",
			workspace_note: "ይህ የህዝብ የደንበኛ ሜኑ አይደለም። ለንግዱና ለሰራተኛው የግል የስራ ቦታ ነው።",
			note: "የስራ ቦታው ሞዴል እዚህ እንደ የምርት አቅጣጫ ይታያል። በዚህ ደረጃ አይሰራም።"
		},
		staff: {
			eyebrow: "የሰራተኛ የስራ ፍሰት",
			title: "ማን ምን ማድረግ እንደሚችል ባለቤቱ ይወስናል።",
			body: "አዳራሹ ፍጥነት ይፈልጋል። ንግዱ ቁጥጥር ይፈልጋል። ሚናዎች ያንን ያስችላሉ — እያንዳንዱን እርምጃ ስብሰባ ሳያደርጉ።",
			owner: "ባለቤት",
			admin: "አስተዳዳሪ / ሥራ አስኪያጅ",
			cashier: "ገንዘብ ተቀባይ",
			waiter: "አስተናጋጅ",
			owner_body: "ሙሉውን ንግድ ያያል። መዳረሻ ይሰጣል። መረጋገጥ ያለበትን ያረጋግጣል።",
			admin_body: "ቤቱን በየቀኑ፣ ባለቤቱ በሰጠው ፈቃድ ውስጥ ያስኬዳል።",
			cashier_body: "ክፍያዎችን ይዘጋል እና ዲጂታል ማስረጃ መዝገብ ከመሆኑ በፊት ያረጋግጣል።",
			waiter_body: "የቃል ትዕዛዝና የክፍያ ማስረጃ ይይዛል ሙሉውን ሥርዓት ሳይወርስ።",
			note: "የሰራተኛ አስተዳደር የኋላ ደረጃ ነው። ይህ ምርቱ የሚገነባበት ሞዴል ነው።"
		},
		payments: {
			eyebrow: "የክፍያ የስራ ፍሰት",
			title: "ክፍያ ተጠያቂ የሆነ ሰው እስኪል ድረስ አይጠናቀቅም።",
			body: "ጥሬ ገንዘብ፣ ቴሌብር፣ የባንክ ማስተላለፍ እና ሌሎች የተዋቀሩ መንገዶች ሁሉ በአንድ ቅደም ተከተል ይገባሉ — ስለዚህ የቀን መዝጊያ መልሶ መገንባት ሳይሆን ማረጋገጫ ነው።",
			order: "ትዕዛዝ",
			unpaid: "ያልተከፈለ",
			submitted: "ክፍያ ቀርቧል",
			pending: "ማረጋገጫ በመጠባበቅ",
			verified: "ተረጋግጧል",
			methods_label: "መንገዶች",
			cash: "ጥሬ ገንዘብ",
			telebirr: "ቴሌብር",
			bank: "የባንክ ማስተላለፍ",
			other: "ሌሎች የተዋቀሩ መንገዶች",
			proof_title: "የዲጂታል ክፍያ ማስረጃ",
			proof_body: "አስተናጋጅ ማስረጃ ሊይዝ ይችላል። ገንዘብ ተቀባይ ወይም ፈቃድ ያለው ሰራተኛ ያረጋግጣል። እምነት ወደ መዝገቡ የሚገባው በዚህ ነው።",
			note: "የቀጥታ የክፍያ ሥርዓቱ የዚህ ደረጃ አካል አይደለም። ከላይ ያለው ቅደም ተከተል የምርቱ ሞዴል ነው።"
		},
		analytics: {
			eyebrow: "ትንታኔ",
			title: "ቀኑ፣ የሚነበብ።",
			body: "ባለቤቶች ንግዱን ከትውስታ መልሰው መገንባት የለባቸውም። የስራ ቦታው ገቢ፣ ትዕዛዝ፣ የክፍያ ድብልቅ፣ ተወዳጅ እቃዎች እና የሰራተኛ እንቅስቃሴን እንደ የተረጋጋ ምስል እንዲያሳይ ተብሎ የተገነባ ነው — እንደ ጫጫታ ሰሌዳ አይደለም።",
			sample: "ለማሳያ የቀረበ መረጃ",
			revenue: "ገቢ",
			orders: "ትዕዛዞች",
			methods: "የክፍያ መንገዶች",
			popular: "ተወዳጅ የሜኑ እቃዎች",
			staff: "የሰራተኛ እንቅስቃሴ",
			trends: "የሰባት ቀን አዝማሚያ",
			cash: "ጥሬ ገንዘብ",
			telebirr: "ቴሌብር",
			bank: "ባንክ",
			items: "እቃዎች",
			tickets: "ትኬቶች"
		},
		pricing: {
			eyebrow: "ዋጋ",
			title: "ከንግድዎ ጋር የሚያድግ እቅድ ይምረጡ።",
			body: "በሙከራ ይጀምሩ። በእውነት በሚያስኬዷቸው ክፍሎች፣ ሰዎች እና ቅርንጫፎች የሚስማማውን እቅድ ይቀጥሉ።",
			explore: "እቅዶችን ይመልከቱ",
			trial: "ነጻ ሙከራ",
			trial_meta: "14 ቀናት",
			trial_body: "የንግድ የስራ ቦታ ይክፈቱ እና የስራ ሞዴሉ ለቤቱ የሚስማማ መሆኑን ይመልከቱ።",
			pro: "Pro",
			pro_plus: "Pro Plus",
			premium: "Premium",
			enterprise: "Enterprise",
			coming: "የእቅድ ዝርዝሮች ምዝገባ ሲከፈት ይታተማሉ። እስካሁን ዋጋ አልተቀመጠም።",
			cta: "እቅዶችን ይመልከቱ"
		},
		cta: {
			title: "ንግድዎ የተሻሉ መሣሪያዎች ይገባዋል።",
			body: "አዳራሹ አሁንም በወረቀት፣ በትውስታ እና ባልተረጋገጠ ማስተላለፍ የሚሠራ ከሆነ፣ መዝገቡን የሚይዝ የተረጋጋ መንገድ አለ።",
			primary: "የ14 ቀን ሙከራዎን ይጀምሩ",
			secondary: "ያናግሩን"
		},
		footer: {
			product: "ምርት",
			features: "ችሎታዎች",
			pricing: "ዋጋ",
			updates: "ዝማኔዎች",
			solutions: "መፍትሄዎች",
			restaurants: "ሬስቶራንቶች",
			hotels: "ሆቴሎች",
			cafes: "ካፌዎች",
			hospitality: "እንግዳ ተቀባይነት",
			company: "ድርጅት",
			about: "ስለ እኛ",
			contact: "ያግኙን",
			careers: "ሥራዎች",
			resources: "መረጃ",
			help: "የእገዛ ማዕከል",
			docs: "ሰነዶች",
			support: "ድጋፍ",
			legal: "ህጋዊ",
			privacy: "ግላዊነት",
			terms: "ውሎች",
			copyright: "© MA’ED MENU",
			tagline: "ለእንግዳ ተቀባይ ንግዶች የሙያ ዲጂታል መሠረተ ልማት።"
		},
		coming: {
			kicker: "የኋላ ደረጃ",
			back: "ወደ መነሻ ተመለስ",
			explore: "ምርቱን ይመልከቱ",
			signup_title: "የንግድ ምዝገባ እየተዘጋጀ ነው።",
			signup_body: "ይጀምሩ በኋላ ደረጃ የንግድ መለያ ይከፍታል። ዛሬ MA’ED MENU ቤቱን እንዴት እንዲያስኬድ እንደተገነባ ማንበብ ይችላሉ።",
			login_title: "መግቢያ ገና አልተከፈተም።",
			login_body: "የሰራተኛና የባለቤት መግቢያ ከንግድ መለያዎች ጋር ይመጣል። በዚህ ደረጃ ምንም የመግቢያ መረጃ አይሰጥም።",
			pricing_title: "እቅዶች፣ ያልተፈጠረ ዋጋ የለም።",
			pricing_body: "MA’ED MENU የ14 ቀን ነጻ ሙከራ፣ ከዚያም Pro፣ Pro Plus፣ Premium እና Enterprise ያቀርባል። የመጨረሻ ዋጋ ምዝገባ ሲከፈት ይታተማል።",
			about_title: "ለእንግዳ ተቀባይነት እንደ መሠረተ ልማት የተገነባ።",
			about_body: "MA’ED MENU ለሬስቶራንት፣ ሆቴል፣ ካፌ፣ ላውንጅ እና ሌሎች የምግብ አገልግሎት ንግዶች የሙያ የስራ ሥርዓት ነው። ከኢትዮጵያ ይጀምራል፣ ለመጓዝ የተዘጋጀ ንድፍ አለው።",
			about_p2: "የመጀመሪያው ምርት የንግድ ጎን ነው። እንግዶች አሁንም ከታተመ ሜኑ በቃል ሊያዙ ይችላሉ። ሥርዓቱ ቤቱ ትዕዛዝ፣ ክፍያ፣ ሰራተኛ፣ ሜኑ እና ቅርንጫፍ በሥርዓት እንዲመዘግብ ነው።",
			contact_title: "ውይይት፣ መንገዱ ሲዘጋጅ።",
			contact_body: "ያናግሩን በኋላ ደረጃ እውነተኛ የመገናኛ መንገድ ይከፍታል። የማይሠራ ቅጽ ወይም የተፈጠረ አድራሻ አንጽፍም።",
			privacy_title: "ግላዊነት",
			privacy_body: "ሙሉ የግላዊነት ፖሊሲ መለያዎች ከመከፈታቸው በፊት ይታተማል። ይህ ደረጃ የንግድ ወይም የግል መለያ መረጃ አይሰበስብም።",
			terms_title: "ውሎች",
			terms_body: "የአጠቃቀም ውሎች ከምዝገባ ጋር ይታተማሉ። ይህ የህዝብ ጣቢያ ለምርቱ መግቢያ ነው እንጂ የመለያ ስምምነት አይደለም።",
			updates_title: "ዝማኔዎች",
			updates_body: "የምርት ዝማኔዎች MA’ED MENU የኋላ ደረጃዎችን ሲከፍት እዚህ ይዘረዘራሉ።",
			careers_title: "ሥራዎች",
			careers_body: "እስካሁን የታተመ ክፍት ሥራ የለም። ሲኖር እዚህ ይታያል።",
			help_title: "የእገዛ ማዕከል",
			help_body: "የእገዛ ጽሑፎች ከሚሠራው ምርት ጋር ይመጣሉ። ይህ ደረጃ የህዝብ መግቢያ ነው።",
			docs_title: "ሰነዶች",
			docs_body: "የአሠራር ሰነድ በቀጥታ የስራ ቦታ ላይ ይጻፋል እንጂ በናሙና ላይ አይደለም።",
			support_title: "ድጋፍ",
			support_body: "የድጋፍ መንገዶች ከንግድ መለያዎች ጋር ይከፈታሉ።",
			features_title: "ችሎታዎች",
			features_body: "የምርት ችሎታዎች በመነሻ ገጹ ላይ ቀርበዋል። የቀጥታ የስራ ቦታው በኋላ ደረጃዎች ይመጣል።"
		},
		demo: {
			sample: "ናሙና",
			waiter: "አስተናጋጅ",
			cashier: "ገንዘብ ተቀባይ",
			manager: "ሥራ አስኪያጅ",
			item_doro: "ዶሮ ወጥ",
			item_tibs: "የበሬ ጥብስ",
			item_shiro: "ሽሮ",
			item_chechebsa: "ጨጨብሳ",
			item_coffee: "አይስድ ቡና",
			staff_hana: "ሃና በቀለ",
			staff_dawit: "ዳዊት ተስፋዬ",
			staff_makeda: "ማከዳ አለሙ",
			staff_yonas: "ዮናስ ኃይሉ",
			table: "ጠረጴዛ",
			open_tickets: "ክፍት ትኬቶች",
			verified_today: "ዛሬ የተረጋገጠ"
		}
	}
};
var THEME_STORAGE_KEY = "maed-theme";
var LANG_STORAGE_KEY = "maed-lang";
function readStorage(key) {
	try {
		return window.localStorage.getItem(key);
	} catch {
		return null;
	}
}
function writeStorage(key, value) {
	try {
		window.localStorage.setItem(key, value);
	} catch {}
}
function isLocale(value) {
	return value === "en" || value === "am";
}
function isThemePreference(value) {
	return value === "light" || value === "dark" || value === "system";
}
function resolveTheme(preference, systemDark) {
	if (preference === "system") return systemDark ? "dark" : "light";
	return preference;
}
function applyDocumentTheme(resolved, preference) {
	const root = document.documentElement;
	root.dataset.theme = resolved;
	root.dataset.themePref = preference;
	root.style.colorScheme = resolved;
}
function applyDocumentLocale(locale) {
	document.documentElement.lang = locale;
}
var I18nContext = (0, import_react.createContext)(null);
function persistLocale(locale) {
	writeStorage(LANG_STORAGE_KEY, locale);
	applyDocumentLocale(locale);
	try {
		document.cookie = `${LANG_STORAGE_KEY}=${locale}; path=/; max-age=31536000; samesite=lax`;
	} catch {}
}
function LanguageProvider({ children }) {
	const [locale, setLocaleState] = (0, import_react.useState)("en");
	(0, import_react.useEffect)(() => {
		const stored = readStorage(LANG_STORAGE_KEY);
		const fromDom = document.documentElement.lang;
		const next = isLocale(stored) ? stored : isLocale(fromDom) ? fromDom : "en";
		setLocaleState(next);
		persistLocale(next);
	}, []);
	const setLocale = (0, import_react.useCallback)((next) => {
		setLocaleState(next);
		persistLocale(next);
	}, []);
	const value = (0, import_react.useMemo)(() => ({
		locale,
		messages: dictionaries[locale],
		setLocale
	}), [locale, setLocale]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(I18nContext.Provider, {
		value,
		children
	});
}
function useI18n() {
	const ctx = (0, import_react.useContext)(I18nContext);
	if (!ctx) throw new Error("useI18n must be used within LanguageProvider");
	return ctx;
}
function useMessages() {
	return useI18n().messages;
}
/** Inline boot script — prevents a flash of the wrong theme/language. */
var THEME_BOOTSTRAP = `(function(){try{var l=localStorage.getItem("maed-lang");if(l==="am"||l==="en")document.documentElement.lang=l;var p=localStorage.getItem("maed-theme")||"system";var d=window.matchMedia("(prefers-color-scheme: dark)").matches;var t=p==="system"?(d?"dark":"light"):p;if(t!=="light"&&t!=="dark")t="light";if(p!=="light"&&p!=="dark"&&p!=="system")p="system";var r=document.documentElement;r.dataset.theme=t;r.dataset.themePref=p;r.style.colorScheme=t;}catch(e){}})();`;
var ThemeContext = (0, import_react.createContext)(null);
function getSystemDark() {
	if (typeof window === "undefined") return false;
	return window.matchMedia("(prefers-color-scheme: dark)").matches;
}
function readPreference() {
	const fromDom = document.documentElement.dataset.themePref ?? null;
	if (isThemePreference(fromDom)) return fromDom;
	const stored = readStorage(THEME_STORAGE_KEY);
	if (isThemePreference(stored)) return stored;
	return "system";
}
function ThemeProvider({ children }) {
	const [preference, setPreferenceState] = (0, import_react.useState)("system");
	const [systemDark, setSystemDark] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setPreferenceState(readPreference());
		setSystemDark(getSystemDark());
		const media = window.matchMedia("(prefers-color-scheme: dark)");
		const onChange = () => setSystemDark(media.matches);
		media.addEventListener("change", onChange);
		return () => media.removeEventListener("change", onChange);
	}, []);
	const resolved = resolveTheme(preference, systemDark);
	(0, import_react.useEffect)(() => {
		applyDocumentTheme(resolved, preference);
	}, [resolved, preference]);
	const setPreference = (0, import_react.useCallback)((next) => {
		setPreferenceState(next);
		writeStorage(THEME_STORAGE_KEY, next);
		applyDocumentTheme(resolveTheme(next, getSystemDark()), next);
	}, []);
	const value = (0, import_react.useMemo)(() => ({
		preference,
		resolved,
		setPreference
	}), [
		preference,
		resolved,
		setPreference
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeContext.Provider, {
		value,
		children
	});
}
function useTheme() {
	const ctx = (0, import_react.useContext)(ThemeContext);
	if (!ctx) throw new Error("useTheme must be used within ThemeProvider");
	return ctx;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function BrandMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("size-7 shrink-0", className),
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "8",
				className: "fill-primary"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M16 5.2 26.2 11v10L16 26.8 5.8 21V11Z",
				fill: "none",
				className: "stroke-gold",
				strokeWidth: "1.4",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M16 11.2 21.4 14.3v6.2L16 23.6l-5.4-3.1v-6.2Z",
				fill: "none",
				className: "stroke-gold",
				strokeWidth: "1.2",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "17.4",
				r: "1.35",
				className: "fill-gold"
			})
		]
	});
}
function Wordmark({ className, compact = false }) {
	const m = useMessages();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: cn("group inline-flex items-center gap-2.5 rounded-sm text-foreground focus-visible:outline-none", className),
		"aria-label": m.brand.name,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-baseline gap-1.5 leading-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-[1.15rem] font-semibold tracking-[-0.03em]",
				children: m.brand.maed
			}), !compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-sans text-[0.68rem] font-semibold tracking-[0.22em] text-muted",
				children: m.brand.menu
			}) : null]
		})]
	});
}
var OPTIONS$1 = [{
	value: "en",
	short: "EN"
}, {
	value: "am",
	short: "አማ"
}];
function LanguageSwitcher({ className }) {
	const { locale, setLocale, messages } = useI18n();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "radiogroup",
		"aria-label": messages.a11y.language,
		className: cn("inline-flex h-9 items-center rounded-md bg-stone/70 p-0.5 shadow-border dark:bg-surface", className),
		children: OPTIONS$1.map(({ value, short }) => {
			const selected = locale === value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				role: "radio",
				"aria-checked": selected,
				"aria-label": messages.language[value],
				title: messages.language[value],
				onClick: () => setLocale(value),
				className: cn("inline-flex h-8 min-w-9 items-center justify-center rounded-sm px-2 text-[0.7rem] font-semibold tracking-wide text-subtle transition-[background-color,color] duration-150 ease-[var(--ease-out)]", selected ? "bg-surface-elevated text-foreground shadow-border" : "hover:text-foreground"),
				children: short
			}, value);
		})
	});
}
function Container({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mx-auto w-full max-w-6xl px-5 sm:px-6 lg:px-8", className),
		...props
	});
}
function Section({ id, className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id,
		className: cn("scroll-mt-24 py-16 sm:py-20 lg:py-24", className),
		...props
	});
}
function Footer() {
	const m = useMessages();
	const columns = [
		{
			title: m.footer.product,
			links: [
				{
					label: m.footer.features,
					to: "/",
					hash: "product"
				},
				{
					label: m.footer.pricing,
					to: "/pricing"
				},
				{
					label: m.footer.updates,
					to: "/updates"
				}
			]
		},
		{
			title: m.footer.solutions,
			links: [
				{
					label: m.footer.restaurants,
					to: "/",
					hash: "solutions"
				},
				{
					label: m.footer.hotels,
					to: "/",
					hash: "solutions"
				},
				{
					label: m.footer.cafes,
					to: "/",
					hash: "solutions"
				},
				{
					label: m.footer.hospitality,
					to: "/",
					hash: "solutions"
				}
			]
		},
		{
			title: m.footer.company,
			links: [
				{
					label: m.footer.about,
					to: "/about"
				},
				{
					label: m.footer.contact,
					to: "/contact"
				},
				{
					label: m.footer.careers,
					to: "/careers"
				}
			]
		},
		{
			title: m.footer.resources,
			links: [
				{
					label: m.footer.help,
					to: "/help"
				},
				{
					label: m.footer.docs,
					to: "/docs"
				},
				{
					label: m.footer.support,
					to: "/support"
				}
			]
		},
		{
			title: m.footer.legal,
			links: [{
				label: m.footer.privacy,
				to: "/privacy"
			}, {
				label: m.footer.terms,
				to: "/terms"
			}]
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "border-t border-border bg-surface",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "py-14 lg:py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-10 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xs text-sm leading-relaxed text-muted",
						children: m.footer.tagline
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					"aria-label": m.a11y.footer_nav,
					className: "grid grid-cols-2 gap-8 sm:grid-cols-3 lg:col-span-8 lg:grid-cols-5",
					children: columns.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.16em] text-subtle uppercase",
						children: col.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2",
						children: col.links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: link.to,
							hash: link.hash,
							className: "text-sm text-muted transition-colors duration-150 hover:text-foreground",
							children: link.label
						}) }, link.label))
					})] }, col.title))
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 flex flex-col gap-4 border-t border-border pt-6 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-subtle",
					children: m.footer.copyright
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageSwitcher, {})]
			})]
		})
	});
}
var OPTIONS = [
	{
		value: "light",
		icon: Sun,
		labelKey: "light"
	},
	{
		value: "dark",
		icon: Moon,
		labelKey: "dark"
	},
	{
		value: "system",
		icon: Monitor,
		labelKey: "system"
	}
];
function ThemeSwitcher({ className }) {
	const { preference, setPreference } = useTheme();
	const m = useMessages();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "radiogroup",
		"aria-label": m.a11y.theme,
		className: cn("inline-flex h-9 items-center rounded-md bg-stone/70 p-0.5 shadow-border dark:bg-surface", className),
		children: OPTIONS.map(({ value, icon: Icon, labelKey }) => {
			const selected = preference === value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				role: "radio",
				"aria-checked": selected,
				"aria-label": m.theme[labelKey],
				title: m.theme[labelKey],
				onClick: () => setPreference(value),
				className: cn("inline-flex size-8 items-center justify-center rounded-sm text-subtle transition-[background-color,color,transform] duration-150 ease-[var(--ease-out)]", selected ? "bg-surface-elevated text-foreground shadow-border" : "hover:text-foreground"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					className: "size-3.5",
					strokeWidth: 1.75
				})
			}, value);
		})
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[background-color,color,box-shadow,transform,opacity] duration-150 ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-45 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			primary: "bg-primary text-primary-foreground shadow-border hover:opacity-90",
			secondary: "bg-surface text-foreground shadow-border hover:shadow-border-hover hover:bg-surface-elevated",
			ghost: "text-foreground hover:bg-stone/70 dark:hover:bg-surface",
			outline: "text-foreground shadow-border hover:bg-surface",
			accent: "bg-accent text-accent-foreground shadow-border hover:opacity-90",
			link: "text-foreground underline-offset-4 hover:underline"
		},
		size: {
			sm: "h-9 rounded-sm px-3.5 text-sm",
			md: "h-11 rounded-md px-5 text-sm",
			lg: "h-12 rounded-md px-6 text-[0.9375rem]"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function useScrolled(threshold = 12) {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > threshold);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, [threshold]);
	return scrolled;
}
function Navbar() {
	const m = useMessages();
	const scrolled = useScrolled();
	const [open, setOpen] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	(0, import_react.useEffect)(() => {
		setOpen(false);
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const onKey = (e) => {
			if (e.key === "Escape") setOpen(false);
		};
		document.addEventListener("keydown", onKey);
		document.body.style.overflow = "hidden";
		return () => {
			document.removeEventListener("keydown", onKey);
			document.body.style.overflow = "";
		};
	}, [open]);
	const links = [
		{
			hash: "product",
			label: m.nav.product
		},
		{
			hash: "solutions",
			label: m.nav.solutions
		},
		{
			to: "/pricing",
			label: m.nav.pricing
		},
		{
			to: "/help",
			label: m.nav.resources
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: cn("sticky top-0 z-40 transition-[background-color,box-shadow,backdrop-filter] duration-200 ease-[var(--ease-out)]", scrolled || open ? "border-b border-border bg-background/80 shadow-border backdrop-blur-md" : "bg-transparent"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "flex h-16 items-center justify-between gap-4 lg:h-[4.25rem]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					"aria-label": m.a11y.primary_nav,
					className: "hidden items-center gap-1 lg:flex",
					children: links.map((link) => "to" in link && link.to ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: link.to,
						className: "rounded-sm px-3 py-2 text-sm font-medium text-muted transition-colors duration-150 hover:text-foreground",
						children: link.label
					}, link.label) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						hash: "hash" in link ? link.hash : void 0,
						className: "rounded-sm px-3 py-2 text-sm font-medium text-muted transition-colors duration-150 hover:text-foreground",
						children: link.label
					}, link.label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden items-center gap-2 lg:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageSwitcher, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeSwitcher, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/login",
								children: m.nav.sign_in
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/signup",
								children: m.nav.get_started
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "inline-flex size-11 items-center justify-center rounded-md text-foreground lg:hidden",
					"aria-label": open ? m.a11y.close_menu : m.a11y.open_menu,
					"aria-expanded": open,
					onClick: () => setOpen((v) => !v),
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("lg:hidden", open ? "block" : "hidden"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-border bg-background",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
					className: "flex flex-col gap-1 py-4",
					children: [
						links.map((link) => "to" in link && link.to ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: link.to,
							className: "rounded-md px-3 py-3 text-base font-medium text-foreground",
							children: link.label
						}, link.label) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							hash: "hash" in link ? link.hash : void 0,
							className: "rounded-md px-3 py-3 text-base font-medium text-foreground",
							onClick: () => setOpen(false),
							children: link.label
						}, link.label)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center justify-between gap-3 px-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageSwitcher, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeSwitcher, {})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-col gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/login",
									children: m.nav.sign_in
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/signup",
									children: m.nav.get_started
								})
							})]
						})
					]
				})
			})
		})]
	});
}
function SiteLayout({ children }) {
	const m = useMessages();
	const hash = useRouterState({ select: (s) => s.location.hash });
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	(0, import_react.useEffect)(() => {
		if (!hash) return;
		const id = hash.replace(/^#/, "");
		const el = document.getElementById(id);
		if (el) el.scrollIntoView({
			behavior: "smooth",
			block: "start"
		});
	}, [hash, pathname]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#main",
				className: "sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-50 focus:rounded-md focus:bg-primary focus:px-3 focus:py-2 focus:text-primary-foreground",
				children: m.a11y.skip
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				id: "main",
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
var styles_default = "/assets/styles-BgISweH5.css";
var APP_NAME = "MA’ED MENU";
var APP_DESCRIPTION = "Professional digital infrastructure for restaurants, hotels, cafés, and lounges.";
var Route$13 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: APP_DESCRIPTION
			},
			{
				name: "theme-color",
				content: "#F6F1E8"
			},
			{
				name: "color-scheme",
				content: "light dark"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700&family=Noto+Sans+Ethiopic:wght@400;500;600;700&family=Noto+Serif+Ethiopic:wght@400;500;600;700&family=Plus+Jakarta+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap"
			}
		]
	}),
	notFoundComponent: NotFoundComponent,
	component: RootDocument
});
function RootDocument() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("head", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: THEME_BOOTSTRAP } })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "antialiased",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LanguageProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$12 = () => import("./routes-C-E2CfmW.mjs");
var Route$12 = createFileRoute("/")({
	component: lazyRouteComponent($$splitComponentImporter$12, "component"),
	head: () => ({ meta: [{ title: "MA’ED MENU — Hospitality operations infrastructure" }, {
		name: "description",
		content: "Professional digital infrastructure for restaurants, hotels, cafés, and lounges. Manage menus, staff, orders, payments, and branches."
	}] })
});
var $$splitComponentImporter$11 = () => import("./about-QuURZTDB.mjs");
var Route$11 = createFileRoute("/about")({
	component: lazyRouteComponent($$splitComponentImporter$11, "component"),
	head: () => ({ meta: [{ title: "About — MA’ED MENU" }] })
});
var $$splitComponentImporter$10 = () => import("./careers-BPKh1oV-.mjs");
var Route$10 = createFileRoute("/careers")({
	component: lazyRouteComponent($$splitComponentImporter$10, "component"),
	head: () => ({ meta: [{ title: "Careers — MA’ED MENU" }] })
});
var $$splitComponentImporter$9 = () => import("./contact-CTaraUj2.mjs");
var Route$9 = createFileRoute("/contact")({
	component: lazyRouteComponent($$splitComponentImporter$9, "component"),
	head: () => ({ meta: [{ title: "Contact — MA’ED MENU" }] })
});
var $$splitComponentImporter$8 = () => import("./docs-BIDOtBo5.mjs");
var Route$8 = createFileRoute("/docs")({
	component: lazyRouteComponent($$splitComponentImporter$8, "component"),
	head: () => ({ meta: [{ title: "Documentation — MA’ED MENU" }] })
});
var $$splitComponentImporter$7 = () => import("./help-DELAqfAW.mjs");
var Route$7 = createFileRoute("/help")({
	component: lazyRouteComponent($$splitComponentImporter$7, "component"),
	head: () => ({ meta: [{ title: "Help Center — MA’ED MENU" }] })
});
var $$splitComponentImporter$6 = () => import("./login-DcQrdQU8.mjs");
var Route$6 = createFileRoute("/login")({
	component: lazyRouteComponent($$splitComponentImporter$6, "component"),
	head: () => ({ meta: [{ title: "Sign in — MA’ED MENU" }] })
});
var $$splitComponentImporter$5 = () => import("./pricing-DskHU-j-.mjs");
var Route$5 = createFileRoute("/pricing")({
	component: lazyRouteComponent($$splitComponentImporter$5, "component"),
	head: () => ({ meta: [{ title: "Pricing — MA’ED MENU" }] })
});
var $$splitComponentImporter$4 = () => import("./privacy-DQYEysdW.mjs");
var Route$4 = createFileRoute("/privacy")({
	component: lazyRouteComponent($$splitComponentImporter$4, "component"),
	head: () => ({ meta: [{ title: "Privacy — MA’ED MENU" }] })
});
var $$splitComponentImporter$3 = () => import("./signup-DO4hxv49.mjs");
var Route$3 = createFileRoute("/signup")({
	component: lazyRouteComponent($$splitComponentImporter$3, "component"),
	head: () => ({ meta: [{ title: "Get started — MA’ED MENU" }] })
});
var $$splitComponentImporter$2 = () => import("./support-BbhSiQVt.mjs");
var Route$2 = createFileRoute("/support")({
	component: lazyRouteComponent($$splitComponentImporter$2, "component"),
	head: () => ({ meta: [{ title: "Support — MA’ED MENU" }] })
});
var $$splitComponentImporter$1 = () => import("./terms-CKwUlPPa.mjs");
var Route$1 = createFileRoute("/terms")({
	component: lazyRouteComponent($$splitComponentImporter$1, "component"),
	head: () => ({ meta: [{ title: "Terms — MA’ED MENU" }] })
});
var $$splitComponentImporter = () => import("./updates-DQbC01tG.mjs");
var Route = createFileRoute("/updates")({
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	head: () => ({ meta: [{ title: "Updates — MA’ED MENU" }] })
});
var rootRouteChildren = {
	IndexRoute: Route$12.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$13
	}),
	AboutRoute: Route$11.update({
		id: "/about",
		path: "/about",
		getParentRoute: () => Route$13
	}),
	CareersRoute: Route$10.update({
		id: "/careers",
		path: "/careers",
		getParentRoute: () => Route$13
	}),
	ContactRoute: Route$9.update({
		id: "/contact",
		path: "/contact",
		getParentRoute: () => Route$13
	}),
	DocsRoute: Route$8.update({
		id: "/docs",
		path: "/docs",
		getParentRoute: () => Route$13
	}),
	HelpRoute: Route$7.update({
		id: "/help",
		path: "/help",
		getParentRoute: () => Route$13
	}),
	LoginRoute: Route$6.update({
		id: "/login",
		path: "/login",
		getParentRoute: () => Route$13
	}),
	PricingRoute: Route$5.update({
		id: "/pricing",
		path: "/pricing",
		getParentRoute: () => Route$13
	}),
	PrivacyRoute: Route$4.update({
		id: "/privacy",
		path: "/privacy",
		getParentRoute: () => Route$13
	}),
	SignupRoute: Route$3.update({
		id: "/signup",
		path: "/signup",
		getParentRoute: () => Route$13
	}),
	SupportRoute: Route$2.update({
		id: "/support",
		path: "/support",
		getParentRoute: () => Route$13
	}),
	TermsRoute: Route$1.update({
		id: "/terms",
		path: "/terms",
		getParentRoute: () => Route$13
	}),
	UpdatesRoute: Route.update({
		id: "/updates",
		path: "/updates",
		getParentRoute: () => Route$13
	})
};
var routeTree = Route$13._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent,
		defaultPreload: "intent",
		scrollRestoration: true
	});
}
//#endregion
export { cn as a, Section as i, Button as n, useMessages as o, Container as r, router_exports as t };
