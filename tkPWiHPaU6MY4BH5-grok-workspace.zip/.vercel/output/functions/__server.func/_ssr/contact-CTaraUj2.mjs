import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as useMessages } from "./router-DmaOi4Rh.mjs";
import { t as ComingSoon } from "./coming-soon-D8VrRrg2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-CTaraUj2.js
var import_jsx_runtime = require_jsx_runtime();
function ContactPage() {
	const m = useMessages();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComingSoon, {
		title: m.coming.contact_title,
		body: m.coming.contact_body
	});
}
//#endregion
export { ContactPage as component };
