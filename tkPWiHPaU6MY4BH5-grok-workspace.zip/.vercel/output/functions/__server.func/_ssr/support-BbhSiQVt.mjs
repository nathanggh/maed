import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as PhasePage } from "./phase-page-D9Sbb-lK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/support-BbhSiQVt.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhasePage, { kind: "support" });
//#endregion
export { SplitComponent as component };
