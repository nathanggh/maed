import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as useMessages } from "./router-DmaOi4Rh.mjs";
import { t as ComingSoon } from "./coming-soon-D8VrRrg2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-QuURZTDB.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	const m = useMessages();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComingSoon, {
		title: m.coming.about_title,
		body: m.coming.about_body,
		extra: m.coming.about_p2
	});
}
//#endregion
export { AboutPage as component };
