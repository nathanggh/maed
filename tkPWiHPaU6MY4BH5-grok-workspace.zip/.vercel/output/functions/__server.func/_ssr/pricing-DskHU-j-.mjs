import { b as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { x as ArrowRight } from "../_libs/lucide-react.mjs";
import { a as cn, n as Button, o as useMessages, r as Container } from "./router-DmaOi4Rh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pricing-DskHU-j-.js
var import_jsx_runtime = require_jsx_runtime();
function PricingPage() {
	const m = useMessages();
	const plans = [
		{
			name: m.pricing.trial,
			meta: m.pricing.trial_meta,
			body: m.pricing.trial_body,
			featured: true
		},
		{
			name: m.pricing.pro,
			meta: "—",
			body: m.pricing.coming,
			featured: false
		},
		{
			name: m.pricing.pro_plus,
			meta: "—",
			body: m.pricing.coming,
			featured: false
		},
		{
			name: m.pricing.premium,
			meta: "—",
			body: m.pricing.coming,
			featured: false
		},
		{
			name: m.pricing.enterprise,
			meta: "—",
			body: m.pricing.coming,
			featured: false
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
		className: "py-16 sm:py-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-[0.18em] text-accent uppercase",
				children: m.pricing.eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 max-w-2xl font-display text-4xl font-medium tracking-[-0.03em] sm:text-5xl",
				children: m.pricing.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 max-w-xl text-lg text-muted",
				children: m.pricing.body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-12 grid gap-4 lg:grid-cols-5",
				children: plans.map((plan) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: cn("rounded-xl p-5", plan.featured ? "bg-primary text-primary-foreground shadow-lift" : "bg-surface shadow-card"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold",
							children: plan.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-display text-2xl font-medium",
							children: plan.meta
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("mt-3 text-sm leading-relaxed", plan.featured ? "text-primary-foreground/80" : "text-muted"),
							children: plan.body
						})
					]
				}, plan.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-sm text-subtle",
				children: m.pricing.coming
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/signup",
						children: [m.cta.primary, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					})
				})
			})
		]
	});
}
//#endregion
export { PricingPage as component };
