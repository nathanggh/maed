import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as require_jsx_runtime, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as ArrowDown, _ as Check, a as Wallet, b as BookOpen, g as ClipboardList, h as Coffee, i as WifiOff, m as GitBranch, n as Wine, o as UtensilsCrossed, p as Hotel, r as Wifi, s as Users, v as ChartLine, x as ArrowRight, y as Building2 } from "../_libs/lucide-react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as cn, i as Section, n as Button, o as useMessages, r as Container } from "./router-DmaOi4Rh.mjs";
import { a as Area, c as ResponsiveContainer, i as XAxis, l as Tooltip, n as BarChart, o as Bar, r as YAxis, s as Cell, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C-E2CfmW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium tracking-wide", {
	variants: { tone: {
		neutral: "bg-stone text-muted",
		bronze: "bg-accent/12 text-accent",
		success: "bg-success/12 text-success",
		info: "bg-info/12 text-info",
		warning: "bg-warning/14 text-warning",
		danger: "bg-danger/12 text-danger"
	} },
	defaultVariants: { tone: "neutral" }
});
function Badge({ className, tone, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ tone }), className),
		...props
	});
}
function SectionHeading({ eyebrow, title, body, align = "left", className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("max-w-2xl", align === "center" && "mx-auto text-center", className),
		children: [
			eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-3 flex items-center gap-3 text-xs font-semibold tracking-[0.18em] text-accent uppercase",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": "true",
						className: cn("h-px w-7 bg-accent/70", align === "center" && "hidden sm:block")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: eyebrow }),
					align === "center" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": "true",
						className: "hidden h-px w-7 bg-accent/70 sm:block"
					}) : null
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl font-medium leading-[1.15] tracking-[-0.03em] text-foreground sm:text-4xl",
				children: title
			}),
			body ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-base leading-relaxed text-muted sm:text-[1.05rem]",
				children: body
			}) : null
		]
	});
}
var TREND = [
	{
		d: "1",
		v: 8400
	},
	{
		d: "2",
		v: 9200
	},
	{
		d: "3",
		v: 7800
	},
	{
		d: "4",
		v: 11e3
	},
	{
		d: "5",
		v: 12480
	},
	{
		d: "6",
		v: 10100
	},
	{
		d: "7",
		v: 13200
	}
];
function AnalyticsPreview() {
	const m = useMessages();
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	const axis = "var(--maed-subtle)";
	const gold = "var(--maed-accent)";
	const mix = [
		{
			name: m.analytics.cash,
			value: 42,
			bar: "bg-accent"
		},
		{
			name: m.analytics.telebirr,
			value: 38,
			bar: "bg-info"
		},
		{
			name: m.analytics.bank,
			value: 20,
			bar: "bg-success"
		}
	];
	const popular = [
		{
			name: m.demo.item_doro,
			v: 42
		},
		{
			name: m.demo.item_tibs,
			v: 31
		},
		{
			name: m.demo.item_shiro,
			v: 24
		},
		{
			name: m.demo.item_coffee,
			v: 19
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
			eyebrow: m.analytics.eyebrow,
			title: m.analytics.title,
			body: m.analytics.body
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			tone: "bronze",
			children: m.analytics.sample
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-12 grid gap-4 lg:grid-cols-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl bg-surface p-5 shadow-revenue lg:col-span-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.14em] text-subtle uppercase",
						children: m.analytics.trends
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-display text-3xl font-medium tabular",
						children: ["12,480", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1.5 font-sans text-sm font-medium text-subtle",
							children: m.hero.currency
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 h-44",
						children: mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
								data: TREND,
								margin: {
									top: 8,
									right: 8,
									left: 0,
									bottom: 0
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
										id: "rev",
										x1: "0",
										y1: "0",
										x2: "0",
										y2: "1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "0%",
											stopColor: gold,
											stopOpacity: .28
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "100%",
											stopColor: gold,
											stopOpacity: 0
										})]
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "d",
										tick: {
											fill: axis,
											fontSize: 11
										},
										axisLine: false,
										tickLine: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { hide: true }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
										background: "var(--maed-surface-elevated)",
										border: "1px solid var(--maed-border)",
										borderRadius: 8,
										fontSize: 12
									} }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
										type: "monotone",
										dataKey: "v",
										stroke: gold,
										strokeWidth: 1.8,
										fill: "url(#rev)"
									})
								]
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full rounded-md bg-stone/50" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl bg-surface p-5 shadow-info lg:col-span-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-[0.14em] text-subtle uppercase",
					children: m.analytics.methods
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 space-y-4",
					children: mix.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: row.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular text-muted",
							children: [row.value, "%"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1.5 h-1.5 overflow-hidden rounded-full bg-stone",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("h-full rounded-full", row.bar),
							style: { width: `${row.value}%` }
						})
					})] }, row.name))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl bg-surface p-5 shadow-card lg:col-span-7",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-[0.14em] text-subtle uppercase",
					children: m.analytics.popular
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 h-44",
					children: mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: popular,
							layout: "vertical",
							margin: {
								top: 0,
								right: 8,
								left: 8,
								bottom: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									type: "number",
									hide: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									type: "category",
									dataKey: "name",
									width: 96,
									tick: {
										fill: axis,
										fontSize: 11
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "v",
									radius: [
										0,
										4,
										4,
										0
									],
									barSize: 12,
									children: popular.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: gold }, entry.name))
								})
							]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full rounded-md bg-stone/50" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl bg-surface p-5 shadow-success lg:col-span-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-[0.14em] text-subtle uppercase",
					children: m.analytics.staff
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-3",
					children: [
						{
							name: m.demo.staff_hana,
							role: m.demo.waiter,
							n: 18
						},
						{
							name: m.demo.staff_dawit,
							role: m.demo.cashier,
							n: 36
						},
						{
							name: m.demo.staff_makeda,
							role: m.demo.manager,
							n: 9
						}
					].map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: row.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-subtle",
							children: row.role
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "tabular text-sm text-muted",
							children: [
								row.n,
								" ",
								m.analytics.tickets
							]
						})]
					}, row.name))
				})]
			})
		]
	})] }) });
}
function CoreValue() {
	const m = useMessages();
	const pillars = [
		{
			icon: BookOpen,
			title: m.value.digital_menu,
			body: m.value.digital_menu_body,
			shadow: "shadow-card"
		},
		{
			icon: Users,
			title: m.value.staff,
			body: m.value.staff_body,
			shadow: "shadow-info"
		},
		{
			icon: ClipboardList,
			title: m.value.orders,
			body: m.value.orders_body,
			shadow: "shadow-warning"
		},
		{
			icon: Wallet,
			title: m.value.payments,
			body: m.value.payments_body,
			shadow: "shadow-success"
		},
		{
			icon: GitBranch,
			title: m.value.branches,
			body: m.value.branches_body,
			shadow: "shadow-info"
		},
		{
			icon: ChartLine,
			title: m.value.insights,
			body: m.value.insights_body,
			shadow: "shadow-revenue"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
		id: "product",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
			eyebrow: m.value.eyebrow,
			title: m.value.title,
			body: m.value.body
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
			children: pillars.map(({ icon: Icon, title, body, shadow }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: cn("rounded-xl bg-surface p-6", shadow),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-10 items-center justify-center rounded-md bg-stone text-accent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-4",
							strokeWidth: 1.75
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-5 text-base font-semibold",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: body
					})
				]
			}, title))
		})] })
	});
}
function FinalCta() {
	const m = useMessages();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
		className: "pb-20 sm:pb-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Container, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl bg-graphite px-6 py-12 text-ivory shadow-lift sm:px-12 sm:py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-2xl font-display text-3xl font-medium tracking-[-0.03em] sm:text-4xl",
					children: m.cta.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-xl text-base leading-relaxed text-ivory/70",
					children: m.cta.body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-col gap-3 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						className: "bg-ivory text-graphite hover:opacity-90",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/signup",
							children: [m.cta.primary, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "lg",
						variant: "outline",
						className: "border-0 bg-transparent text-ivory ring-1 ring-ivory/20 hover:bg-ivory/10",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							children: m.cta.secondary
						})
					})]
				})
			]
		}) })
	});
}
function useCountUp(target) {
	const [value, setValue] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
			setValue(target);
			return;
		}
		let start = null;
		let frame = 0;
		const tick = (t) => {
			if (start === null) start = t;
			const p = Math.min(1, (t - start) / 900);
			setValue(Math.round(target * (1 - (1 - p) ** 3)));
			if (p < 1) frame = requestAnimationFrame(tick);
		};
		frame = requestAnimationFrame(tick);
		return () => cancelAnimationFrame(frame);
	}, [target]);
	return value;
}
function Sparkline({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 120 36",
		className: cn("h-9 w-[7.5rem]", className),
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M0 28 C12 26, 18 22, 28 20 S48 24, 58 16 S78 6, 90 10 S110 18, 120 8",
			fill: "none",
			className: "stroke-accent",
			strokeWidth: "1.6",
			strokeLinecap: "round"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M0 28 C12 26, 18 22, 28 20 S48 24, 58 16 S78 6, 90 10 S110 18, 120 8 V36 H0 Z",
			className: "fill-accent/15"
		})]
	});
}
function HeroPreview() {
	const m = useMessages();
	const revenue = useCountUp(12480);
	const orders = useCountUp(48);
	const pending = useCountUp(12);
	const verified = useCountUp(36);
	const staff = [
		{
			name: m.demo.staff_hana,
			role: m.demo.waiter,
			state: "ok"
		},
		{
			name: m.demo.staff_dawit,
			role: m.demo.cashier,
			state: "wait"
		},
		{
			name: m.demo.staff_makeda,
			role: m.demo.manager,
			state: "ok"
		}
	];
	const items = [
		{
			name: m.demo.item_doro,
			qty: 14
		},
		{
			name: m.demo.item_tibs,
			qty: 11
		},
		{
			name: m.demo.item_shiro,
			qty: 9
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "preview-stage relative",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("preview-frame overflow-hidden rounded-xl bg-surface-elevated shadow-preview", "maed-enter"),
			style: { animationDelay: "120ms" },
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-border px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-danger/70" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-warning/80" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-success/70" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 text-xs font-medium tracking-wide text-subtle",
							children: m.brand.name
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "bronze",
						children: m.hero.preview_sample
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden text-xs text-subtle sm:inline",
						children: m.hero.preview_today
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "col-span-3 hidden border-r border-border bg-stone/40 py-4 pr-2 pl-3 sm:block dark:bg-surface",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-2 text-[0.65rem] font-semibold tracking-[0.16em] text-subtle uppercase",
						children: m.hero.preview_label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-1 text-xs",
						children: [
							m.value.insights,
							m.value.digital_menu,
							m.value.orders,
							m.value.payments,
							m.value.staff
						].map((label, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: cn("rounded-sm px-2 py-1.5", i === 0 ? "bg-surface-elevated font-medium text-foreground shadow-border" : "text-muted"),
							children: label
						}, label))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "col-span-12 space-y-3 p-3 sm:col-span-9 sm:p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
							className: "rounded-lg bg-surface p-4 shadow-revenue",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-wide text-muted",
									children: m.hero.metric_revenue
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 font-display text-3xl font-medium tracking-[-0.03em] tabular",
									children: [revenue.toLocaleString(), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-1.5 text-sm font-sans font-medium text-subtle",
										children: m.hero.currency
									})]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, {})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								{
									label: m.hero.metric_orders,
									value: orders,
									shadow: "shadow-info"
								},
								{
									label: m.hero.metric_pending,
									value: pending,
									shadow: "shadow-warning"
								},
								{
									label: m.hero.metric_verified,
									value: verified,
									shadow: "shadow-success"
								}
							].map((card) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: cn("rounded-md bg-surface px-3 py-3", card.shadow),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[0.65rem] font-medium tracking-wide text-muted",
									children: card.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-display text-xl font-medium tabular",
									children: card.value
								})]
							}, card.label))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "rounded-md bg-surface p-3 shadow-card",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[0.65rem] font-semibold tracking-[0.14em] text-subtle uppercase",
									children: m.hero.staff_activity
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-2 space-y-2",
									children: staff.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "truncate text-xs font-medium",
												children: person.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[0.65rem] text-subtle",
												children: person.role
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-1.5 shrink-0 rounded-full", person.state === "ok" ? "bg-success" : "bg-warning") })]
									}, person.name))
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "rounded-md bg-surface p-3 shadow-card",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[0.65rem] font-semibold tracking-[0.14em] text-subtle uppercase",
									children: m.hero.menu_activity
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-2 space-y-2",
									children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center justify-between gap-2 text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate font-medium",
											children: item.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "tabular text-muted",
											children: item.qty
										})]
									}, item.name))
								})]
							})]
						})
					]
				})]
			})]
		})
	});
}
function Hero() {
	const m = useMessages();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative overflow-hidden pt-10 pb-16 sm:pt-14 sm:pb-20 lg:pt-16 lg:pb-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			"aria-hidden": "true",
			className: "pointer-events-none absolute inset-0 bg-[radial-gradient(70%_50%_at_78%_0%,color-mix(in_oklab,var(--maed-gold)_10%,transparent),transparent_68%)]"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, {
			className: "relative grid items-center gap-12 lg:grid-cols-12 lg:gap-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "maed-enter mb-4 text-xs font-semibold tracking-[0.18em] text-accent uppercase",
						style: { animationDelay: "40ms" },
						children: m.hero.eyebrow
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "maed-enter font-display text-[2.35rem] leading-[1.08] font-medium tracking-[-0.035em] text-foreground sm:text-5xl lg:text-[3.35rem]",
						style: { animationDelay: "80ms" },
						children: m.hero.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "maed-enter mt-5 max-w-md text-base leading-relaxed text-muted sm:text-lg",
						style: { animationDelay: "140ms" },
						children: m.hero.subtitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "maed-enter mt-8 flex flex-col gap-3 sm:flex-row sm:items-center",
						style: { animationDelay: "200ms" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "lg",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/signup",
								children: [m.hero.cta_primary, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "lg",
							variant: "secondary",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								hash: "product",
								children: m.hero.cta_secondary
							})
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:col-span-7 lg:pl-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "maed-float",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroPreview, {})
				})
			})]
		})]
	});
}
function HowItWorks() {
	const m = useMessages();
	const steps = [
		{
			n: "01",
			title: m.how.step1_title,
			body: m.how.step1_body
		},
		{
			n: "02",
			title: m.how.step2_title,
			body: m.how.step2_body
		},
		{
			n: "03",
			title: m.how.step3_title,
			body: m.how.step3_body
		},
		{
			n: "04",
			title: m.how.step4_title,
			body: m.how.step4_body
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
		className: "bg-surface",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
			eyebrow: m.how.eyebrow,
			title: m.how.title,
			body: m.how.body
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",
			children: steps.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "relative",
				children: [
					i < steps.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": "true",
						className: "absolute top-5 left-[2.25rem] hidden h-px w-[calc(100%-1rem)] bg-border lg:block"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl font-medium text-accent/80",
						children: step.n
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-3 text-base font-semibold",
						children: step.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: step.body
					})
				]
			}, step.n))
		})] })
	});
}
function MultiBusiness() {
	const m = useMessages();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
		className: "bg-surface",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Container, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid items-start gap-12 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					eyebrow: m.multi.eyebrow,
					title: m.multi.title,
					body: m.multi.body
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-sm text-subtle",
					children: m.multi.note
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:col-span-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-background p-5 shadow-card sm:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-[0.16em] text-subtle uppercase",
							children: m.multi.owner
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-3 border-l border-border pl-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold",
									children: m.multi.hotel
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "mt-2 space-y-1 border-l border-border pl-4 text-sm text-muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: m.multi.hotel_bole }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: m.multi.hotel_airport })]
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold",
									children: m.multi.cafe
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold",
									children: m.multi.restaurant
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 rounded-lg bg-surface p-4 shadow-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium text-muted",
										children: m.multi.workspace
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: "bronze",
										children: m.hero.preview_sample
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 font-mono text-sm text-foreground",
									children: m.multi.workspace_example
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted",
									children: m.multi.workspace_note
								})
							]
						})
					]
				})
			})]
		}) })
	});
}
function Flow({ title, icon, steps }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-xl bg-surface p-6 shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex size-9 items-center justify-center rounded-md bg-stone text-accent",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(icon, {
					className: "size-4",
					strokeWidth: 1.75
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-semibold tracking-[0.12em] uppercase",
				children: title
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "mt-5",
			children: steps.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-col items-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-md bg-background px-3 py-2 text-sm font-medium shadow-border",
					children: step
				}), i < steps.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, {
					className: "my-1.5 ml-3 size-3.5 text-subtle",
					strokeWidth: 1.5
				}) : null]
			}, step))
		})]
	});
}
function Offline() {
	const m = useMessages();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
			eyebrow: m.offline.eyebrow,
			title: m.offline.title,
			body: m.offline.body
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-12 grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flow, {
				title: m.offline.online,
				icon: Wifi,
				steps: [
					m.offline.online,
					m.offline.order,
					m.offline.payment,
					m.offline.sync
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flow, {
				title: m.offline.offline,
				icon: WifiOff,
				steps: [
					m.offline.offline,
					m.offline.order_saved,
					m.offline.payment_recorded,
					m.offline.connection_returns,
					m.offline.secure_sync
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-sm text-subtle",
			children: m.offline.note
		})
	] }) });
}
function Operations() {
	const m = useMessages();
	const steps = [
		m.operations.step_order,
		m.operations.step_record,
		m.operations.step_total,
		m.operations.step_pay,
		m.operations.step_proof,
		m.operations.step_verify,
		m.operations.step_owner
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
		className: "bg-surface",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: m.operations.eyebrow,
				title: m.operations.title,
				body: m.operations.body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-12 max-w-xl",
				children: steps.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "relative flex gap-4 pb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex w-8 shrink-0 flex-col items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-8 items-center justify-center rounded-full bg-background font-display text-sm text-accent shadow-border",
							children: i + 1
						}), i < steps.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, {
							className: "my-1 size-3.5 text-subtle",
							strokeWidth: 1.5
						}) : null]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pt-1.5 text-sm font-medium sm:text-base",
						children: step
					})]
				}, step))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 max-w-xl text-sm text-subtle",
				children: m.operations.note
			})
		] })
	});
}
function PaymentWorkflow() {
	const m = useMessages();
	const steps = [
		{
			label: m.payments.order,
			tone: "neutral"
		},
		{
			label: m.payments.unpaid,
			tone: "warning"
		},
		{
			label: m.payments.submitted,
			tone: "info"
		},
		{
			label: m.payments.pending,
			tone: "warning"
		},
		{
			label: m.payments.verified,
			tone: "success"
		}
	];
	const methods = [
		m.payments.cash,
		m.payments.telebirr,
		m.payments.bank,
		m.payments.other
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
		className: "bg-surface",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: m.payments.eyebrow,
				title: m.payments.title,
				body: m.payments.body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 overflow-x-auto pb-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "flex min-w-max items-center gap-2",
					children: steps.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("rounded-md px-3 py-2 text-sm font-medium shadow-border", step.tone === "success" && "bg-success/12 text-success shadow-success", step.tone === "warning" && "bg-warning/12 text-warning shadow-warning", step.tone === "info" && "bg-info/12 text-info shadow-info", step.tone === "neutral" && "bg-background text-foreground"),
							children: step.label
						}), i < steps.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
							className: "size-4 text-subtle",
							strokeWidth: 1.5
						}) : null]
					}, step.label))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-background p-5 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.14em] text-subtle uppercase",
						children: m.payments.methods_label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex flex-wrap gap-2",
						children: methods.map((method) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "neutral",
							children: method
						}) }, method))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-background p-5 shadow-success",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-[0.14em] text-subtle uppercase",
						children: m.payments.proof_title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: m.payments.proof_body
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-subtle",
				children: m.payments.note
			})
		] })
	});
}
function PricingTeaser() {
	const m = useMessages();
	const plans = [
		{
			name: m.pricing.trial,
			meta: m.pricing.trial_meta,
			featured: true
		},
		{
			name: m.pricing.pro,
			meta: "—",
			featured: false
		},
		{
			name: m.pricing.pro_plus,
			meta: "—",
			featured: false
		},
		{
			name: m.pricing.premium,
			meta: "—",
			featured: false
		},
		{
			name: m.pricing.enterprise,
			meta: "—",
			featured: false
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
		id: "pricing",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				eyebrow: m.pricing.eyebrow,
				title: m.pricing.title,
				body: m.pricing.body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-5",
				children: plans.map((plan) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: cn("rounded-xl p-5", plan.featured ? "bg-primary text-primary-foreground shadow-lift" : "bg-surface shadow-card"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold",
							children: plan.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("mt-2 font-display text-2xl font-medium", plan.featured ? "text-primary-foreground" : "text-foreground"),
							children: plan.meta
						}),
						plan.featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-primary-foreground/80",
							children: m.pricing.trial_body
						}) : null
					]
				}, plan.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-subtle",
				children: m.pricing.coming
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/pricing",
						children: [m.pricing.explore, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					})
				})
			})
		] })
	});
}
function StaffWorkflow() {
	const m = useMessages();
	const roles = [
		{
			title: m.staff.owner,
			body: m.staff.owner_body
		},
		{
			title: m.staff.admin,
			body: m.staff.admin_body
		},
		{
			title: m.staff.cashier,
			body: m.staff.cashier_body
		},
		{
			title: m.staff.waiter,
			body: m.staff.waiter_body
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
			eyebrow: m.staff.eyebrow,
			title: m.staff.title,
			body: m.staff.body
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-12 flex flex-col gap-3 lg:flex-row lg:items-stretch",
			children: roles.map((role, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col items-stretch lg:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "flex-1 rounded-xl bg-surface p-5 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-[0.16em] text-accent uppercase",
							children: String(i + 1).padStart(2, "0")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 text-base font-semibold",
							children: role.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted",
							children: role.body
						})
					]
				}), i < roles.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center justify-center px-1 py-1 lg:px-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, {
						className: "size-4 text-subtle lg:-rotate-90",
						strokeWidth: 1.5
					})
				}) : null]
			}, role.title))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-sm text-subtle",
			children: m.staff.note
		})
	] }) });
}
function Trust() {
	const m = useMessages();
	const items = [
		{
			icon: UtensilsCrossed,
			title: m.trust.restaurants,
			body: m.trust.restaurants_body
		},
		{
			icon: Hotel,
			title: m.trust.hotels,
			body: m.trust.hotels_body
		},
		{
			icon: Coffee,
			title: m.trust.cafes,
			body: m.trust.cafes_body
		},
		{
			icon: Wine,
			title: m.trust.lounges,
			body: m.trust.lounges_body
		},
		{
			icon: Building2,
			title: m.trust.hospitality,
			body: m.trust.hospitality_body
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
		className: "pt-4 sm:pt-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-2xl text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-[0.18em] text-accent uppercase",
					children: m.trust.eyebrow
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-2xl font-medium tracking-[-0.03em] sm:text-3xl",
					children: m.trust.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted",
					children: m.trust.body
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-5",
			children: items.map(({ icon: Icon, title, body }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-lg bg-surface px-4 py-5 shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-4 text-accent",
						strokeWidth: 1.75
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm font-semibold",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1.5 text-sm leading-relaxed text-muted",
						children: body
					})
				]
			}, title))
		})] })
	});
}
function UseCases() {
	const m = useMessages();
	const [active, setActive] = (0, import_react.useState)("restaurants");
	const cases = {
		restaurants: {
			label: m.use_cases.restaurants,
			lead: m.use_cases.restaurants_lead,
			body: m.use_cases.restaurants_body,
			caps: [
				m.use_cases.restaurants_c1,
				m.use_cases.restaurants_c2,
				m.use_cases.restaurants_c3
			],
			preview: [
				m.demo.item_doro,
				m.demo.item_tibs,
				m.demo.item_shiro
			]
		},
		cafes: {
			label: m.use_cases.cafes,
			lead: m.use_cases.cafes_lead,
			body: m.use_cases.cafes_body,
			caps: [
				m.use_cases.cafes_c1,
				m.use_cases.cafes_c2,
				m.use_cases.cafes_c3
			],
			preview: [
				m.demo.item_coffee,
				m.demo.item_chechebsa,
				m.demo.item_shiro
			]
		},
		hotels: {
			label: m.use_cases.hotels,
			lead: m.use_cases.hotels_lead,
			body: m.use_cases.hotels_body,
			caps: [
				m.use_cases.hotels_c1,
				m.use_cases.hotels_c2,
				m.use_cases.hotels_c3
			],
			preview: [
				m.multi.hotel_bole,
				m.multi.hotel_airport,
				m.multi.cafe
			]
		},
		lounges: {
			label: m.use_cases.lounges,
			lead: m.use_cases.lounges_lead,
			body: m.use_cases.lounges_body,
			caps: [
				m.use_cases.lounges_c1,
				m.use_cases.lounges_c2,
				m.use_cases.lounges_c3
			],
			preview: [
				m.demo.staff_hana,
				m.demo.staff_dawit,
				m.demo.staff_yonas
			]
		},
		other: {
			label: m.use_cases.other,
			lead: m.use_cases.other_lead,
			body: m.use_cases.other_body,
			caps: [
				m.use_cases.other_c1,
				m.use_cases.other_c2,
				m.use_cases.other_c3
			],
			preview: [
				m.demo.item_chechebsa,
				m.demo.item_coffee,
				m.demo.item_tibs
			]
		}
	};
	const current = cases[active];
	const keys = Object.keys(cases);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
		id: "solutions",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Container, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
			eyebrow: m.use_cases.eyebrow,
			title: m.use_cases.title,
			body: m.use_cases.body
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-10 grid gap-8 lg:grid-cols-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-1 lg:col-span-4 lg:flex-col lg:overflow-visible",
				children: keys.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setActive(key),
					className: cn("min-h-11 shrink-0 rounded-md px-4 py-3 text-left text-sm font-medium transition-colors duration-150", active === key ? "bg-primary text-primary-foreground shadow-border" : "bg-surface text-muted shadow-border hover:text-foreground"),
					children: cases[key].label
				}, key))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:col-span-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-xl bg-surface p-6 shadow-card sm:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-2xl font-medium tracking-[-0.03em]",
							children: current.lead
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted sm:text-base",
							children: current.body
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-6 space-y-2",
							children: current.caps.map((cap) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
									className: "mt-0.5 size-4 shrink-0 text-accent",
									strokeWidth: 1.75
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: cap })]
							}, cap))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 rounded-lg bg-background p-4 shadow-border",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3 flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold tracking-[0.14em] text-subtle uppercase",
									children: m.hero.preview_label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "bronze",
									children: m.hero.preview_sample
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "space-y-2",
								children: current.preview.map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center justify-between rounded-sm bg-surface px-3 py-2 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: row
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular text-subtle",
										children: i === 0 ? "01" : i === 1 ? "02" : "03"
									})]
								}, row))
							})]
						})
					]
				})
			})]
		})] })
	});
}
function LandingPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trust, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoreValue, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HowItWorks, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UseCases, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Operations, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Offline, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MultiBusiness, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StaffWorkflow, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaymentWorkflow, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnalyticsPreview, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PricingTeaser, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})
	] });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LandingPage, {});
}
//#endregion
export { Home as component };
